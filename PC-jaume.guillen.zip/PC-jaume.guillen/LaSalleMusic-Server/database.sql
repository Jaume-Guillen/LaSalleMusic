DROP DATABASE IF EXISTS LSMusic;
CREATE DATABASE LSMusic;
USE LSMusic;

DROP TABLE IF EXISTS Usuari CASCADE;
CREATE TABLE Usuari(

	nom_usuari VARCHAR(255),
	email VARCHAR(255),
	contrasenya VARCHAR(255),
	data_registre VARCHAR(255),
	darrer_acces VARCHAR(255),
	PRIMARY KEY(nom_usuari)

);

DROP TABLE IF EXISTS Amics CASCADE;
CREATE TABLE Amics(

	nom_amic1 VARCHAR(255),
	nom_amic2 VARCHAR(255),
	PRIMARY KEY(nom_amic1, nom_amic2),
	FOREIGN KEY(nom_amic1) REFERENCES Usuari(nom_usuari) ON DELETE CASCADE,
	FOREIGN KEY(nom_amic2) REFERENCES Usuari(nom_usuari) ON DELETE CASCADE

);

DROP TABLE IF EXISTS LlistaReproduccio CASCADE;
CREATE TABLE LlistaReproduccio(

	id_llista INT,
	nom VARCHAR(255),
	nom_usuari VARCHAR(255),
	PRIMARY KEY(id_llista),
	FOREIGN KEY(nom_usuari) REFERENCES Usuari(nom_usuari) ON DELETE CASCADE

);

DROP TABLE IF EXISTS Canco CASCADE;
CREATE TABLE Canco(

	path_canco VARCHAR(255),
	nom VARCHAR(255),
	genere VARCHAR(255),
	album VARCHAR(255),
	artista VARCHAR(255),
	estrelles float,
	reproduccions_totals INT,
	PRIMARY KEY(path_canco)

);

DROP TABLE IF EXISTS Vot CASCADE;
CREATE TABLE Vot(

	nom_usuari VARCHAR(255),
	path_canco VARCHAR(255),
	estrelles INT,
	PRIMARY KEY(nom_usuari, path_canco),
	FOREIGN KEY(nom_usuari) REFERENCES Usuari(nom_usuari) ON DELETE CASCADE,
	FOREIGN KEY(path_canco) REFERENCES Canco(path_canco) ON DELETE CASCADE

);

DROP TABLE IF EXISTS CancoLlista CASCADE;
CREATE TABLE CancoLlista(

  path_canco VARCHAR(255),
  id_llista INT,
  PRIMARY KEY(path_canco, id_llista),
  FOREIGN KEY(path_canco) REFERENCES Canco(path_canco) ON DELETE CASCADE,
  FOREIGN KEY(id_llista) REFERENCES LlistaReproduccio(id_llista) ON DELETE CASCADE

);