package com.company.Model;

import com.google.gson.Gson;

import java.io.FileReader;

/**
 * Classe que s'encarrega de la configuracio a partir del fitxer config.json.
 */

public class Config {

    private static int port_base;
    private static String ip;
    private static String nom_base;
    private static String usuari_base;
    private static String contrasenya_base;
    private static int port_comunicacio;
    private static Config instance;

    /**
     * Constructor de la classe Config.
     * @param port_base Port de la base de dades.
     * @param ip IP de la connexio.
     * @param nom_base Nom de la base de dades.
     * @param usuari_base Usuari del host de MySQL.
     * @param contrasenya_base Contrasenya del host de MySQL.
     * @param port_comunicacio Port de comunicacio amb el client.
     */

    public Config(int port_base, String ip, String nom_base, String usuari_base, String contrasenya_base, int port_comunicacio) {
        this.port_base = port_base;
        this.ip = ip;
        this.nom_base = nom_base;
        this.usuari_base = usuari_base;
        this.contrasenya_base = contrasenya_base;
        this.port_comunicacio = port_comunicacio;
        instance = null;
    }

    /**
     * Obte una instancia de la classe Config. Si no s'ha fet ja, llegeix el fitxer config.json.
     * @return Una instancia de Config.
     */

    public static Config getInstance(){
        if(instance == null){
            try {
                FileReader r = new FileReader("config.json");
                JSONClass j = new Gson().fromJson(r, JSONClass.class);
                instance = new Config((int)j.getPort_base(), j.getIp(), j.getNom_base(), j.getUsuari_base(), j.getContrasenya_base(), (int)j.getPort_comunicacio());
                System.out.println(instance.getNom_base());
            }catch(Exception e){

                e.printStackTrace();

            }
        }
        return instance;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public int getPort_base() {
        return port_base;
    }

    public void setPort_base(int port) {
        this.port_base = port;
    }

    public String getNom_base() {
        return nom_base;
    }

    public void setNom_base(String nom_base) {
        this.nom_base = nom_base;
    }

    public String getUsuari_base() {
        return usuari_base;
    }

    public void setUsuari_base(String usuari_base) {
        this.usuari_base = usuari_base;
    }

    public String getContrasenya_base() {
        return contrasenya_base;
    }

    public void setContrasenya_base(String contrasenya_base) {
        this.contrasenya_base = contrasenya_base;
    }

    public int getPort_comunicacio() {
        return port_comunicacio;
    }

    public void setPort_comunicacio(int port_comunicacio) {
        this.port_comunicacio = port_comunicacio;
    }
}
