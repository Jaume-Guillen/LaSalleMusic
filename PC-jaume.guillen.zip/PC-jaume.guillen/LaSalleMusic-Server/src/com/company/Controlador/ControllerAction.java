package com.company.Controlador;

import com.company.Model.Canco;
import com.company.Model.LlistaReproduccio;
import com.company.Model.Manager;
import com.company.Model.Usuari;
import com.company.Vista.*;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;

/**
 *Classe que controla les accions realitzades amb botons.
 */

public class ControllerAction implements ActionListener {

    Finestra f;
    Manager m;
    LinkedList<Canco> cancons;
    LinkedList<Usuari> usuaris;

    /**
     * Constructor que genera un ControllerAction.
     * @param f La finestra activa en aquest moment.
     * @param m El manager des d'on gestionem la base de dades.
     */

    public ControllerAction(Finestra f, Manager m){

        this.f = f;
        this.m = m;

    }

    /**
     * Funcio que comprova que fer quan s'ha premut un JButton.
     * @param e Parametre que comprova quin JButton s'ha apretat.
     */


    @Override
    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();
        ControllerAction cReg;
        ControllerAction cLog;
        ControllerAction cUn;
        ControllerAction cIn;
        ControllerMouse cm;

        switch(action){

            case FinestraInici.UNIRSE:
                FinestraRegistre fr = new FinestraRegistre(640,420);
                cReg = new ControllerAction(fr, m);
                fr.registerController(cReg);
                fr.setVisible(true);
                ((JFrame) f).dispose();
                break;

            case FinestraInici.ACCEDIR:
                FinestraLogin fl = new FinestraLogin(640,420);
                cLog = new ControllerAction(fl, m);
                fl.registerController(cLog);
                fl.setVisible(true);
                ((JFrame) f).dispose();
                break;

            case FinestraRegistre.REGISTER:
                Usuari user = new Usuari();
                FinestraRegistre aux = (FinestraRegistre) f;
                String registre = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
                if(user.RegistraUsuari(((FinestraRegistre) f).getNomUsuari(), ((FinestraRegistre) f).getContrasenya(), ((FinestraRegistre) f).getEmail(), registre, registre)){

                    if(((FinestraRegistre) f).getContrasenya().equals(((FinestraRegistre) f).getRepetir())) {


                        LinkedList<Usuari> users = m.getUsuaris();

                        boolean diferent = true;

                        for (int i = 0; i < users.size(); i++) {

                            if (users.get(i).getNom_usuari().equals(((FinestraRegistre) f).getNomUsuari())) {

                                diferent = false;

                            }

                        }

                        if (diferent) {

                            FinestraMenu fm = new FinestraMenu(640, 420);
                            cUn = new ControllerAction(fm, m);
                            fm.registerController(cUn);
                            fm.setVisible(true);
                            m.addUsuari(user);
                            ((JFrame) f).dispose();
                        } else {

                            ((FinestraRegistre) f).contrasenyaError("Error! Ja hi ha un usuari amb aquest nom!");

                        }
                    }else{

                        ((FinestraRegistre) f).contrasenyaError("Error! T'has equivocat al repetir la contrasenya!");

                    }

                }else{

                    ((FinestraRegistre) f).contrasenyaError("Error! La contrasenya ha de tenir 6 o mes caracters, algun numero i tant majuscules com minuscules.");

                }
                break;

            case FinestraRegistre.BACK:
                FinestraInici fi = new FinestraInici(640,420);
                cIn = new ControllerAction(fi, m);
                fi.registerController(cIn);
                fi.setVisible(true);
                ((JFrame) f).dispose();
                break;

            case FinestraLogin.LOGIN:
                LinkedList<Usuari> usuaris = m.getUsuaris();
                String nom = ((FinestraLogin) f).getNomUsuari();
                String contrasenya = ((FinestraLogin) f).getContrasenya();
                boolean trobat = false;
                for(int i = 0; i < usuaris.size(); i++){


                    if(nom.equals(usuaris.get(i).getNom_usuari()) && contrasenya.equals(usuaris.get(i).getContrasenya())){

                        Usuari us = new Usuari();
                        String acces = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
                        us.RegistraUsuari(nom, contrasenya, usuaris.get(i).getEmail(), usuaris.get(i).getData_registre(), acces);
                        m.modificaAcces(nom);
                        FinestraMenu fm = new FinestraMenu(640, 420);
                        cUn = new ControllerAction(fm, m);
                        fm.registerController(cUn);
                        fm.setVisible(true);
                        ((JFrame) f).dispose();
                        trobat = true;

                    }

                }

                if(trobat == false){

                    ((FinestraLogin) f).contrasenyaError();

                }
                break;

            case FinestraMenu.USUARIS:
                LinkedList<Usuari> users = m.getUsuaris();

                FinestraUsuaris fu = new FinestraUsuaris(640,420, users, m);
                cIn = new ControllerAction(fu, m);
                cIn.setUsuaris(users);
                cm = new ControllerMouse(fu);
                fu.registerController(cIn);
                fu.registerMouse(cm);
                fu.setVisible(true);
                ((JFrame) f).dispose();
                break;

            case FinestraMenu.CANCONS:
                LinkedList<Canco> c = m.getCancons();
                FinestraCancons fc = new FinestraCancons(640,420, c);
                cIn = new ControllerAction(fc, m);
                cIn.setCancons(c);
                cm = new ControllerMouse(fc);
                fc.registerController(cIn);
                fc.registerMouse(cm);
                fc.setVisible(true);
                ((JFrame) f).dispose();
                break;


            case FinestraUsuaris.MENU:
                FinestraMenu fm = new FinestraMenu(640, 420);
                cUn = new ControllerAction(fm, m);
                fm.registerController(cUn);
                fm.setVisible(true);
                ((JFrame) f).dispose();
                break;

            case FinestraCancons.ADDSONG:
                FinestraAfegirCanco fa = new FinestraAfegirCanco(640, 420);
                cUn = new ControllerAction(fa, m);
                fa.registerController(cUn);
                fa.setVisible(true);
                ((JFrame) f).dispose();
                break;

            case FinestraCancons.STATS:
                LinkedList<Canco> top10 = m.getCanconsOrdenades();
                FinestraEstadistiques fe = new FinestraEstadistiques(640, 420, top10);
                cUn = new ControllerAction(fe, m);
                fe.registerController(cUn);
                fe.setVisible(true);
                ((JFrame) f).dispose();
                break;


            case FinestraAfegirCanco.FITXER:
                int returnVal = ((FinestraAfegirCanco) f).getFc().showOpenDialog(((FinestraAfegirCanco) f));

                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    File file = ((FinestraAfegirCanco) f).getFc().getSelectedFile();
                    String path = file.toURI().getPath();
                    ((FinestraAfegirCanco) f).setPath(path);
                    System.out.println(path);


                } else {

                    ((FinestraAfegirCanco) f).afegirError("Error! No s'ha trobat la canco!");

                }

                break;

            case FinestraAfegirCanco.AFEGIR:
                FinestraAfegirCanco auxiliar = (FinestraAfegirCanco)f;
                if(!auxiliar.getAlbum().equals("") && !auxiliar.getArtista().equals("") && !auxiliar.getGenere().equals("") && !auxiliar.getNom().equals("") && !auxiliar.getPath().equals("")){

                    LinkedList<Canco> cancons = m.getCancons();
                    boolean b = false;

                    for(int i = 0; i < cancons.size(); i++){

                        if(cancons.get(i).getPath_canco().equals(auxiliar.getPath())){

                            b = true;

                        }

                    }

                    if(!b){

                        Canco ca = new Canco(auxiliar.getPath(), auxiliar.getNom(), auxiliar.getGenere(), auxiliar.getAlbum(), auxiliar.getArtista(), 0, 0);
                        m.addCanco(ca);
                        LinkedList<Canco> cs = m.getCancons();
                        FinestraCancons fic = new FinestraCancons(640,420, cs);
                        cIn = new ControllerAction(fic, m);
                        cIn.setCancons(cs);
                        cm = new ControllerMouse(fic);
                        fic.registerController(cIn);
                        fic.registerMouse(cm);
                        fic.setVisible(true);
                        ((JFrame) f).dispose();


                    }else{

                        ((FinestraAfegirCanco) f).afegirError("Error! Aquesta canco ja existeix en el sistema!");

                    }

                }else{

                    ((FinestraAfegirCanco) f).afegirError("Error! S'han d'emplenar tots els camps!");

                }

                break;

            case FinestraAfegirCanco.MENUCANCONS:

                LinkedList<Canco> css = m.getCancons();
                FinestraCancons finc = new FinestraCancons(640,420, css);
                cIn = new ControllerAction(finc, m);
                cIn.setCancons(css);
                cm = new ControllerMouse(finc);
                finc.registerController(cIn);
                finc.registerMouse(cm);
                finc.setVisible(true);
                ((JFrame) f).dispose();
                break;

            case FinestraCancons.ELIMINARCANCO:

                FinestraCancons auxc = (FinestraCancons)f;
                eliminarCanco(this.cancons.get(auxc.getRowindex()).getPath_canco());

                break;

            case FinestraUsuaris.ELIMINARUSUARI:

                FinestraUsuaris auxu = (FinestraUsuaris)f;
                eliminarUsuari(this.usuaris.get(auxu.getRowindex()).getNom_usuari());

        }
    }

    /**
     * Eliminar un usuari de la base de dades.
     * @param nom_usuari FK de l'usuari a eliminar.
     */

    public void eliminarUsuari(String nom_usuari){

        m.deleteUsuari(nom_usuari);
        ControllerAction cIn;
        LinkedList<Usuari> users = m.getUsuaris();
        LinkedList<LlistaReproduccio> llistes = m.getLlistesUsuari(nom_usuari);
        int countCanco = 0;
        for(int i = 0; i < llistes.size(); i++){

            LinkedList<Canco> cancons = m.getCanconsLlista(llistes.get(i).getId_llistaReproduccio());
            countCanco += cancons.size();

        }
        FinestraUsuaris fu = new FinestraUsuaris(640,420, users, m);
        cIn = new ControllerAction(fu, m);
        cIn.setUsuaris(users);
        ControllerMouse cm = new ControllerMouse(fu);
        fu.registerController(cIn);
        fu.registerMouse(cm);
        fu.setVisible(true);
        ((JFrame) f).dispose();

    }

    /**
     * Elimina una canco de la base de dades.
     * @param path_canco FK de la canco a eliminar.
     */

    public void eliminarCanco(String path_canco){

        m.deleteCanco(path_canco);

        ControllerAction cIn;
        LinkedList<Canco> cs = m.getCancons();
        FinestraCancons fc = new FinestraCancons(640,420, cs);
        cIn = new ControllerAction(fc, m);
        cIn.setCancons(cs);
        ControllerMouse cm = new ControllerMouse(fc);
        fc.registerController(cIn);
        fc.registerMouse(cm);
        fc.setVisible(true);
        ((JFrame) f).dispose();

    }

    public void setCancons(LinkedList<Canco> cancons) {
        this.cancons = cancons;
    }

    public void setUsuaris(LinkedList<Usuari> usuaris) {
        this.usuaris = usuaris;
    }
}
