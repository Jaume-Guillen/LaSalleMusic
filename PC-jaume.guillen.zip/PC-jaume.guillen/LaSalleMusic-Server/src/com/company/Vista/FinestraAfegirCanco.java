package com.company.Vista;

import com.company.Controlador.ControllerAction;
import com.company.Controlador.ControllerMouse;
import com.company.Model.Usuari;

import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import java.awt.*;
import java.io.File;

/**
 * Finestra des d'on podem afegir una canco a la base de dades.
 */

public class FinestraAfegirCanco extends JFrame implements Finestra{

    public final static String FITXER = "BUSCAR CANCO";
    public final static String MENUCANCONS = "TORNAR ENRERA";
    public final static String AFEGIR = "AFEGEIX CANCO";
    JButton botoBuscar;
    JButton botoEnrera;
    JButton botoAfegir;
    JTextField nom_tf;
    JTextField genere_tf;
    JTextField album_tf;
    JTextField artista_tf;
    JLabel errorFitxer;
    JPanel textFields;
    JFileChooser fc = new JFileChooser();
    String path = "";

    /**
     * Inicialitza la finestra.
     * @param w Amplada de la finestra.
     * @param h Llargada de la finestra.
     */

    public FinestraAfegirCanco(int w, int h){

        setSize(new Dimension(w, h));
        setTitle("LaSalle Music");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        textFields = new JPanel();
        textFields.setLayout(null);
        textFields.setBounds(0, 0, w, h);
        textFields.setMaximumSize(new Dimension(w, 3*h/4));
        nom_tf = new JTextField("");
        nom_tf.setMaximumSize(new Dimension(w/3, 3*h/16));
        genere_tf = new JTextField("");
        album_tf = new JTextField("");
        artista_tf = new JTextField("");
        errorFitxer = new JLabel("Error! Algun camp esta buit!.");
        errorFitxer.setBounds(w/50, h/10, w - w/50, h/4);
        errorFitxer.setVisible(false);
        textFields.add(errorFitxer);
        JLabel nom__l = new JLabel("Nom: ");
        JLabel genere_l = new JLabel("Genere: ");
        JLabel artista_l = new JLabel("Artista: ");
        JLabel album_l = new JLabel("Album: ");
        nom__l.setBounds(w/2 - w/10, h/4, w/2, h/16);
        textFields.add(nom__l);
        textFields.add(nom_tf);
        nom_tf.setBounds(w/2 + w/100, h/4, w/2 - w/10, h/16);
        genere_l.setBounds(w/2 - w/9 - w/1000, h/4 + h/8, w/2 - w/5, h/16);
        textFields.add(genere_l);
        genere_tf.setBounds(w/2 + w/100, h/4 + h/8, w/2 - w/10, h/16);
        album_l.setBounds(w/2 - w/6 - w/100, 5*h/8, w/2 - w/5, h/16);
        album_tf.setBounds(w/2 + w/80, 5*h/8, w/2 - w/10, h/16);
        textFields.add(genere_tf);
        textFields.add(album_l);
        textFields.add(album_tf);
        artista_tf.setBounds(w/2 + w/100, h/2, w/2 - w/10, h/16);
        artista_l.setBounds(w/2 - w/18, h/2, w/2 - w/5, h/16);
        textFields.add(artista_l);
        textFields.add(artista_tf);
        botoBuscar = new JButton(FITXER);
        botoBuscar.setBounds(w/4 - w/8, h/2 + h/4, w/4, h/16);
        textFields.add(botoBuscar);
        botoEnrera = new JButton(MENUCANCONS);
        botoEnrera.setBounds(3*w/4 - w/8, h/2 + h/4, w/4, h/16);
        textFields.add(botoEnrera);
        botoAfegir = new JButton(AFEGIR);
        botoAfegir.setBounds(w/2 - w/8, h/2 + h/4, w/4, h/16);
        textFields.add(botoAfegir);
        fc.setFileFilter(new FileFilter() {
            @Override
            public boolean accept(File f) {
                if (f.isDirectory()) {
                    return true;
                } else {
                    String filename = f.getName().toLowerCase();
                    return filename.endsWith(".mp3");
                }
            }

            @Override
            public String getDescription() {
                return "MP3 files (.mp3)";
            }
        });

        add(textFields);

    }

    @Override
    public void registerController(ControllerAction c) {

        this.botoBuscar.setActionCommand(FITXER);
        this.botoBuscar.addActionListener(c);
        this.botoEnrera.setActionCommand(MENUCANCONS);
        this.botoEnrera.addActionListener(c);
        this.botoAfegir.setActionCommand(AFEGIR);
        this.botoAfegir.addActionListener(c);

    }

    @Override
    public void registerMouse(ControllerMouse c) {

    }

    public String getNom(){

        return nom_tf.getText();

    }

    public String getGenere(){

        return genere_tf.getText();

    }

    public String getArtista(){

        return artista_tf.getText();

    }

    public String getAlbum(){

        return album_tf.getText();

    }

    /**
     * Motrar un missatge d'error per pantalla.
     * @param text Missatge que mostrar.
     */

    public void afegirError(String text){

        errorFitxer.setText(text);
        errorFitxer.setForeground(Color.RED);
        errorFitxer.setVisible(true);
        textFields.validate();
        textFields.repaint();

    }

    public JFileChooser getFc() {
        return fc;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
