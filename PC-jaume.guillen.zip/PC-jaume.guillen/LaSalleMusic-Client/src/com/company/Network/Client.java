package com.company.Network;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

/**
 * Client de l'aplicacio.
 */

public class Client extends Thread{

    Socket s;
    PrintWriter out;

    private ObjectInputStream objectIn = null;

    private ObjectOutputStream objectOut = null;

    /**
     * Constructor del client.
     * @param host IP del host.
     * @param port Port de comunicacio.
     * @throws IOException
     */

    public Client(String host, int port) throws IOException {

        try{

            s = new Socket(host, port);
            this.objectOut = new ObjectOutputStream(s.getOutputStream());
            objectOut.flush();
            this.objectIn = new ObjectInputStream(s.getInputStream());

        }catch(Exception e){

            e.printStackTrace();

        }

    }

    /**
     * El client corre en paralel.
     */

    public void run(){

        try {

            while(true){

            }

        }catch(Exception e){

            e.printStackTrace();

        }

    }

    /**
     * Envia un missatge per demanar un obsecte al servidor.
     * @param message Filtre per saber quin objecte vol.
     * @return Objecte que vol el client.
     */

    public Object sendMessage(String message){

        try{
            objectOut.writeObject(message);

            Object o = objectIn.readObject();

            System.out.println("Carregat objecte de la classe " + o.getClass().getSimpleName());

            return o;
        }catch(Exception e){

            e.printStackTrace();

        }

        return null;

    }

    /**
     * Envia un missatge al servidor per a escriure un objecte a continuacio.
     * @param message Filtre per saber quin objecte vol enviar.
     */

    public void sendWriteMessage(String message){

        try{
            objectOut.writeObject(message);

        }catch(Exception e){

            e.printStackTrace();

        }
    }

    /**
     * Envia un objecte al servidor.
     * @param o Objecte que vol enviar.
     */

    public void sendObject(Object o){

        try{
            objectOut.writeObject(o);
            objectOut.flush();

        }catch(Exception e){

            e.printStackTrace();

        }

    }

}
