package com.company.Vista;

import com.company.Controlador.ControllerAction;
import com.company.Controlador.ControllerMouse;
import com.company.Model.Canco;
import com.company.Model.LlistaReproduccio;
import com.company.Model.Manager;
import com.company.Model.Usuari;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.LinkedList;

/**
 * Finestra que mostra tots els usuaris de la base de dades.
 */

public class FinestraUsuaris extends JFrame implements Finestra{

    public final static String MENU = "MENU";
    public final static String ELIMINARUSUARI = "Eliminar Usuari";
    JTable taula;
    JPopupMenu popup = new JPopupMenu("Eliminar");
    JMenuItem JEliminar = new JMenuItem("Eliminar");
    JMenuItem JCancelar = new JMenuItem("Cancelar");
    JButton JbEnrera = new JButton(MENU);
    int rowindex = -1;

    /**
     * Inicialitza la finestra i la mostra per pantalla.
     * @param w Amplada de la finestra.
     * @param h Llargada de la finestra.
     * @param usuaris Llistat de tots els usuaris.
     * @param m Manager de la base de dades.
     */

    public FinestraUsuaris(int w, int h, LinkedList<Usuari> usuaris, Manager m){

        setSize(new Dimension(w, h));
        setTitle("LaSalle Music");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        String[] columnNames = {"Nom d'usuari", "Data registre", "Data darrer acces", "Numero llistes", "Numero total cancons"};
        Object[][] data = new Object[usuaris.size()][5];



        for(int i = 0; i < usuaris.size(); i++){

            LinkedList<LlistaReproduccio> llistes = m.getLlistesUsuari(usuaris.get(i).getNom_usuari());
            int countCanco = 0;
            for(int j = 0; j < llistes.size(); j++){

                LinkedList<Canco> cancons = m.getCanconsLlista(llistes.get(j).getId_llistaReproduccio());
                countCanco += cancons.size();

            }

            data[i][0] = usuaris.get(i).getNom_usuari();
            data[i][1] = usuaris.get(i).getData_registre();
            data[i][2] = usuaris.get(i).getDarrer_acces();
            data[i][3] = llistes.size();
            data[i][4] = countCanco;

        }

        taula = new JTable(data, columnNames);

        JbEnrera.setBounds(w/2 - w/16, h - h/8, w/8, h/16);

        popup.add(JEliminar);
        popup.add(JCancelar);

        this.add(new JScrollPane(taula));
        this.add(JbEnrera, BorderLayout.SOUTH);

    }

    public void registerController(ControllerAction c){

        this.JEliminar.setActionCommand(ELIMINARUSUARI);
        this.JEliminar.addActionListener(c);

        this.JbEnrera.setActionCommand(MENU);
        this.JbEnrera.addActionListener(c);

    }

    @Override
    public void registerMouse(ControllerMouse c) {

        taula.addMouseListener(c);

    }

    public JTable getTaula() {
        return taula;
    }

    public JPopupMenu getPopup() {
        return popup;
    }

    public int getRowindex() {
        return rowindex;
    }

    public void setRowindex(int rowindex) {
        this.rowindex = rowindex;
    }
}
