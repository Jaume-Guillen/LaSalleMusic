package com.company.Model;

import com.google.gson.Gson;

import java.io.FileReader;

/**
 * Classe que s'encarrega de la configuracio a partir del fitxer config.json.
 */

public class Config {

    private static String ip;
    private static int port;
    private static Config instance;

    /**
     * Constructor de la classe Config.
     * @param ip IP de la connexio.
     * @param port Port de comunicacio amb el servidor.
     */

    public Config(String ip, int port) {
        this.ip = ip;
        this.port = port;
        instance = null;
    }

    /**
     * Obte una instancia de la classe Config. Si no s'ha fet ja, llegeix el fitxer config.json.
     * @return Una instancia de Config.
     */

    public static Config getInstance(){
        if(instance == null){
            try {
                FileReader r = new FileReader("config.json");
                JSONClass j = new Gson().fromJson(r, JSONClass.class);
                instance = new Config(j.getIp(), (int)j.getPort());
            }catch(Exception e){

                e.printStackTrace();

            }
        }
        return instance;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }
}
