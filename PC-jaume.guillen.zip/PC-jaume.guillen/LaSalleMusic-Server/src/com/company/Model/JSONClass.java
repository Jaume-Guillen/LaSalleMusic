package com.company.Model;

/**
 * Classe auxiliar per llegir el JSON.
 */

public class JSONClass {
    private float port_base;
    private String ip;
    private String nom_base;
    private String usuari_base;
    private String contrasenya_base;
    private float port_comunicacio;


    // Getter Methods

    public float getPort_base() {
        return port_base;
    }

    public String getIp() {
        return ip;
    }

    public String getNom_base() {
        return nom_base;
    }

    public String getUsuari_base() {
        return usuari_base;
    }

    public String getContrasenya_base() {
        return contrasenya_base;
    }

    public float getPort_comunicacio() {
        return port_comunicacio;
    }

    // Setter Methods

    public void setPort_base(float port_base) {
        this.port_base = port_base;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public void setNom_base(String nom_base) {
        this.nom_base = nom_base;
    }

    public void setUsuari_base(String usuari_base) {
        this.usuari_base = usuari_base;
    }

    public void setContrasenya_base(String contrasenya_base) {
        this.contrasenya_base = contrasenya_base;
    }

    public void setPort_comunicacio(float port_comunicacio) {
        this.port_comunicacio = port_comunicacio;
    }
}