package com.company.Network;

import com.company.Model.*;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;

/**
 * Servidor individual per a un client.
 */

public class DedicatedServer extends Thread{

    ServerSocket listener;
    Socket s;
    Server server;

    Manager m;

    /**
     * Constructor del servidor.
     * @param listener Socket del servidor.
     * @param s Socket del client.
     * @param server Servidor general.
     */

    public DedicatedServer(ServerSocket listener, Socket s, Server server) {
        this.listener = listener;
        this.s = s;
        m = new Manager();
        this.server = server;
    }

    /**
     * El servidor corre en paralel per tal de detectar ordres del client.
     */

    public void run(){

        String request;

        boolean serverOn = true;

        while (serverOn) {

            try{

                ObjectOutputStream objectOut = new ObjectOutputStream(s.getOutputStream());
                objectOut.flush();
                ObjectInputStream objectIn = new ObjectInputStream(s.getInputStream());



                while(serverOn){

                    try{

                        request = (String) objectIn.readObject();
                        if (request.equals("RU")) {

                            objectOut.writeObject(m.getUsuaris());

                        }

                        if (request.equals("WU")) {

                            Usuari u = (Usuari) objectIn.readObject();
                            m.addUsuari(u);

                        }

                        if (request.equals("RC")) {

                            LinkedList<Canco> cs = m.getCancons();


                            if(cs != null){

                                objectOut.writeObject(cs);

                            }else{

                                objectOut.writeObject(new LinkedList<Canco>());

                            }

                        }

                        if (request.equals("RL")) {

                            LinkedList<LlistaReproduccio> ls= m.getLlistes();

                            if(ls != null) {

                                objectOut.writeObject(ls);

                            }else{

                                objectOut.writeObject(new LinkedList<LlistaReproduccio>());

                            }

                        }

                        if (request.equals("WL")) {

                            objectOut.flush();

                            LlistaReproduccio l = (LlistaReproduccio) objectIn.readObject();
                            m.addLlista(l);

                        }

                        if (request.equals("WLC")) {

                            objectOut.flush();

                            int l = (int) objectIn.readObject();
                            String c = (String) objectIn.readObject();
                            m.addLlistaCanco(l, c);

                        }

                        if (request.startsWith("MA")) {

                            String[] s = request.split("-", 2);
                            objectOut.writeObject(s[0]);
                            m.modificaAcces(s[1]);

                        }

                        if (request.startsWith("IV")) {

                            String[] s = request.split("-", 2);
                            objectOut.writeObject(s[0]);
                            m.incrementaVisualitzacions(s[1]);

                        }

                        if (request.startsWith("EL")) {

                            String[] s = request.split("-", 2);
                            objectOut.writeObject(s[0]);
                            m.deleteLlista(Integer.parseInt(s[1]));

                        }

                        if (request.startsWith("RCL")) {

                            String[] s = request.split("-", 2);
                            LinkedList<Canco> cs = m.getCanconsLlista(Integer.parseInt(s[1]));
                            objectOut.writeObject(cs);

                        }

                        if (request.startsWith("RLU")) {

                            String[] s = request.split("-", 2);
                            LinkedList<LlistaReproduccio> ls = m.getLlistesUsuari(s[1]);
                            objectOut.writeObject(ls);

                        }

                        if (request.equals("ECL")) {

                            String c = (String) objectIn.readObject();
                            int l = (int) objectIn.readObject();

                            m.deleteCancoLlista(c, l);

                        }

                        if(request.equals("UV")){

                            Vot v = (Vot) objectIn.readObject();
                            m.addVot(v);
                            m.updateVot(v);

                        }




                    }catch(Exception e){

                        e.printStackTrace();
                        serverOn = false;
                        this.interrupt();
                        server.getDs().remove(this);

                    }



                }

            } catch (Exception e) {

                this.interrupt();
                serverOn = false;
                server.getDs().remove(this);
                e.printStackTrace();

            }
        }

    }
}
