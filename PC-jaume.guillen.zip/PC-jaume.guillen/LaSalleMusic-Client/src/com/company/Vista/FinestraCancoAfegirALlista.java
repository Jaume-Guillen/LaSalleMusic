package com.company.Vista;

import com.company.Controlador.ControllerAction;
import com.company.Controlador.ControllerMouse;
import com.company.Model.Canco;
import com.company.Model.LlistaReproduccio;
import com.company.Model.Usuari;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.LinkedList;

/**
 * Finestra per afegir una canco a una llista.
 */

public class FinestraCancoAfegirALlista extends JFrame implements Finestra{

    public final static String TORNAR = "TORNAR";
    JTable taula;
    JButton JbEnrera = new JButton(TORNAR);
    JPanel JpButtons = new JPanel();

    int rowindex = -1;

    /**
     * Inicialitza la finestra i la mostra.
     * @param w Amplada de la finestra.
     * @param h Llargada de la finestra.
     * @param llistes Llistes de l'usuari.
     */

    public FinestraCancoAfegirALlista(int w, int h, LinkedList<LlistaReproduccio> llistes){

        setSize(new Dimension(w, h));
        setTitle("LaSalle Music");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        String[] columnNames = {"Nom llista"};
        Object[][] data = new Object[llistes.size()][4];

        for(int i = 0; i < llistes.size(); i++){

            data[i][0] = llistes.get(i).getNom();

        }

        taula = new JTable(data, columnNames);

        taula.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);



        JbEnrera.setBounds(w/2 - w/16, h - h/8, w/8, h/16);
        JpButtons.setBounds(0, h - h/8, w, h/16);
        JpButtons.add(JbEnrera);
        this.add(new JScrollPane(taula));
        this.add(JpButtons, BorderLayout.SOUTH);

    }

    public void registerController(ControllerAction c){

        this.JbEnrera.setActionCommand(TORNAR);
        this.JbEnrera.addActionListener(c);


    }

    @Override
    public void registerMouse(ControllerMouse c) {
        taula.addMouseListener(c);
    }

    public JTable getTaula() {
        return taula;
    }

    public int getRowindex() {
        return rowindex;
    }

    public void setRowindex(int rowindex) {
        this.rowindex = rowindex;
    }
}