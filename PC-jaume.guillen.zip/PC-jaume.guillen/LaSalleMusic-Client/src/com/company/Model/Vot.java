package com.company.Model;

import java.io.Serializable;

/**
 * Vot fet per un Usuari a una anco.
 */

public class Vot implements Serializable {

    String nom_usuari;
    String path_canco;
    int estrelles;
    static final long serialVersionUID = 45L;

    /**
     * Constructor del vot.
     * @param nom_usuari FK de l'usuari que ha fet el vot.
     * @param path_canco FK de la canco a la que s'ha fet el vot.
     * @param estrelles Puntuacio que s'ha fet en el vot.
     */

    public Vot(String nom_usuari, String path_canco, int estrelles) {
        this.nom_usuari = nom_usuari;
        this.path_canco = path_canco;
        this.estrelles = estrelles;
    }

    public String getNom_usuari() {
        return nom_usuari;
    }

    public void setNom_usuari(String nom_usuari) {
        this.nom_usuari = nom_usuari;
    }

    public String getPath_canco() {
        return path_canco;
    }

    public void setPath_canco(String path_canco) {
        this.path_canco = path_canco;
    }

    public int getEstrelles() {
        return estrelles;
    }

    public void setEstrelles(int estrelles) {
        this.estrelles = estrelles;
    }
}
