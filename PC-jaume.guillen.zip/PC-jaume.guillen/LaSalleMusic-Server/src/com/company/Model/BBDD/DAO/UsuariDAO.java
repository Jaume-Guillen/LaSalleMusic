package com.company.Model.BBDD.DAO;

import com.company.Model.Usuari;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;

/**
 * Classe des d'on gestionem la taula Usuari de la base de dades.
 */

public class UsuariDAO {

    /**
     * Constructor buit de UsuariDAO.
     */

    public UsuariDAO() {



    }

    /**
     * Afageix un Usuari a la base de dades.
     * @param u Usuari que volem afegir.
     */

    public void addUsuari(Usuari u) {

        String registre = new SimpleDateFormat("dd-MM-yyyy").format(new Date());

        DBConnector.getInstance().insertQuery("INSERT INTO Usuari(nom_usuari, email, contrasenya, data_registre, darrer_acces) VALUES ('"+u.getNom_usuari()+"', '"+u.getEmail()+"', '"+u.getContrasenya()+"', '"+registre+"', '"+registre+"');");

    }

    /**
     * Ens permet obtenir tots els usuaris de la base de dades.
     * @return LinkedList amb tots els usuaris.
     */

    public LinkedList<Usuari> getAllUsuaris() {
        LinkedList<Usuari> usuaris = new LinkedList<>();
        ResultSet resultat = DBConnector.getInstance().selectQuery("SELECT nom_usuari, email, contrasenya, data_registre, darrer_acces FROM Usuari;");
        try{
            while(resultat.next()){
                String nom_usuari = resultat.getString("nom_usuari");
                String email = resultat.getString("email");
                String contrasenya = resultat.getString("contrasenya");
                String data_registre = resultat.getString("data_registre");
                String darrer_acces = resultat.getString("darrer_acces");
                Usuari u = new Usuari();
                u.RegistraUsuari(nom_usuari, contrasenya, email, data_registre, darrer_acces);
                usuaris.add(u);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return usuaris;
    }

    /**
     * Ens permet eliminar un usuari.
     * @param nom_usuari FK de l'usuari que volem eliminar.
     */

    public void deleteUsuari(String nom_usuari) {
        DBConnector.getInstance().deleteQuery("DELETE FROM Usuari WHERE nom_usuari = '"+nom_usuari+"';");
    }

    /**
     * Modfica la data de darrer acces d'un usuari.
     * @param nom_usuari FK de l'usuari del que volem modificar la data.
     */

    public void modificaAcces(String nom_usuari){

        String acces = new SimpleDateFormat("dd-MM-yyyy").format(new Date());

        DBConnector.getInstance().updateQuery("UPDATE Usuari SET darrer_acces = '" + acces + "' WHERE nom_usuari LIKE '" + nom_usuari + "';");

    }

}
