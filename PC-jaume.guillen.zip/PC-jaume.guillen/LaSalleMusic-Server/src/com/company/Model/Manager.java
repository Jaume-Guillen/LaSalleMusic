package com.company.Model;

import com.company.Model.BBDD.DAO.CancoDAO;
import com.company.Model.BBDD.DAO.LlistaDAO;
import com.company.Model.BBDD.DAO.UsuariDAO;
import com.company.Model.BBDD.DAO.VotDAO;

import java.util.LinkedList;

/**
 * Clase que es comunica amb tots els DAOs per gestionar la base.
 */

public class Manager {

    private CancoDAO cancoDAO;
    private LlistaDAO llistaDAO;
    private UsuariDAO usuariDAO;
    private VotDAO votDAO;

    /**
     * Constructor del Manager.
     */

    public Manager(){

        cancoDAO = new CancoDAO();
        llistaDAO = new LlistaDAO();
        usuariDAO = new UsuariDAO();
        votDAO = new VotDAO();

    }

    /**
     * Afegeix una canco a la base de dades.
     * @param c Canco a afegir.
     */

    public void addCanco(Canco c){

        cancoDAO.addCanco(c);

    }

    /**
     * Afegeix una llista a la base de dades.
     * @param l Llista a afegir.
     */

    public void addLlista(LlistaReproduccio l){

        llistaDAO.addLlista(l);

    }

    /**
     * Afageix una canco a una llista.
     * @param id_llista FK de la llista a la que volem afegir una canco.
     * @param path_canco FK de la canco que volem afegir a la llista.
     */

    public void addLlistaCanco(int id_llista, String path_canco){

        llistaDAO.addLlistaCanco(id_llista, path_canco);

    }

    /**
     * Afegeix un usuari a la base de dades.
     * @param u Usuari que volem afegir.
     */

    public void addUsuari(Usuari u){

        usuariDAO.addUsuari(u);

    }

    /**
     * Afegeix un vot a la base de dades.
     * @param v Vot que volem afegir.
     */

    public void addVot(Vot v){

        votDAO.addVot(v);

    }

    /**
     * Obte totes les cancons de la base de dades.
     * @return Totes les cancons.
     */

    public LinkedList<Canco> getCancons(){

        return cancoDAO.getAllCancons();

    }

    /**
     * Obte el top 10 de cancons amb mes reproduccions.
     * @return Top 10 de cancons de la base de dades.
     */

    public LinkedList<Canco> getCanconsOrdenades(){

        return cancoDAO.getCanconsOrdenat();

    }

    /**
     * Obte totes les llistes de reproduccio.
     * @return Totes les llistes.
     */

    public LinkedList<LlistaReproduccio> getLlistes(){

        return llistaDAO.getAllLlistes();

    }

    /**
     * Obte totes les llistes d'un usuari.
     * @param fk FK de l'usuari del que volem totes les llistes.
     * @return Totes les llistes d'aquell usuari.
     */

    public LinkedList<LlistaReproduccio> getLlistesUsuari(String fk){

        return llistaDAO.getLlistesUsuari(fk);

    }

    /**
     * Obte totes les cancons d'una llista.
     * @param fk FK de la llista de la que volem totes les cancons.
     * @return Totes les cancons d'aquella llista.
     */

    public LinkedList<Canco> getCanconsLlista(int fk){

        return cancoDAO.getCanconsLlista(fk);

    }

    /**
     * Obte tots els usuaris de la base de dades.
     * @return Tots els usuaris.
     */

    public LinkedList<Usuari> getUsuaris(){

        return usuariDAO.getAllUsuaris();

    }

    /**
     * Obte tots els vots de la base de dades.
     * @return Tots els vots.
     */

    public LinkedList<Vot> getVots(){

        return votDAO.getAllVots();

    }

    /**
     * Elimina una canco de la base de dades.
     * @param path_canco FK de la canco a eliminar.
     */

    public void deleteCanco(String path_canco) {

        cancoDAO.deleteCanco(path_canco);

    }

    /**
     * Elimina una llista de la base de dades.
     * @param id_llista FK de la llista que volem eliminar.
     */

    public void deleteLlista(int id_llista) {

        LinkedList<Canco> cancons = getCanconsLlista(id_llista);
        for(int i = 0; i < cancons.size(); i++){

            llistaDAO.deleteCancoLlista(cancons.get(i).getPath_canco(), id_llista);

        }
        llistaDAO.deleteLlista(id_llista);

    }

    /**
     * Elimina una canco d'una llista.
     * @param path_canco FK de la canco que volem eliminar de la llista.
     * @param id_llista FK de la llista de la que volem eliminar una canco.
     */

    public void deleteCancoLlista(String path_canco, int id_llista) {

        llistaDAO.deleteCancoLlista(path_canco, id_llista);

    }

    /**
     * Elimina un usuari d'una llista.
     * @param nom_usuari FK de l'usuari que volem eliminar.
     */

    public void deleteUsuari(String nom_usuari) {

        usuariDAO.deleteUsuari(nom_usuari);

    }

    /**
     * Actualitza el darrer acces d'un usuari al programa.
     * @param nom_usuari FK de l'usuari del que volem actualitzar el darrer acces.
     */

    public void modificaAcces(String nom_usuari) {

        usuariDAO.modificaAcces(nom_usuari);

    }

    /**
     * Incrementa en 1 les visualitzacions d'una canco.
     * @param fk FK de la canco de la que volem incrementar les visualitzacions.
     */

    public void incrementaVisualitzacions(String fk){

        cancoDAO.incrementaVisualitzacions(fk);

    }

    /**
     * Elimina un vot de la base de dades.
     * @param nom_usuari FK de l'usuari del que volem eliminar un vot.
     * @param path_canco FK de la canco de la que volem eliminar un vot.
     */

    public void deleteVot(String nom_usuari, String path_canco) {

        votDAO.deleteVot(nom_usuari, path_canco);

    }

    /**
     * Actualitza un vot de la base de dades.
     * @param v Vot que volem actualitzar.
     */

    public void updateVot(Vot v){

        votDAO.updateVot(v);
        cancoDAO.calculaEstrelles(v.getPath_canco());

    }

}
