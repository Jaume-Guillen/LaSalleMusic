package com.company.Vista;

import com.company.Controlador.ControllerAction;
import com.company.Controlador.ControllerMouse;

import javax.swing.*;
import java.awt.*;

/**
 * Finestra d'inici, des d'on l'usuari es pot registrar o iniciar sessio.
 */

public class FinestraInici extends JFrame implements Finestra{
    public final static String UNIRSE = "UNEIX-TE!";
    public final static String ACCEDIR = "ACCEDEIX";
    JButton botoRegistre;
    JButton botoIniciSessio;

    /**
     * Inicialitza la finestra i la mostra.
     * @param w Amplada de la finestra.
     * @param h Llargada de la finestra.
     */

    public FinestraInici(int w, int h){

        setSize(new Dimension(w, h));
        setTitle("LaSalle Music");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        JPanel titol = new JPanel();
        titol.setMaximumSize(new Dimension(w, h/2));
        JPanel botons = new JPanel();
        botons.setMaximumSize(new Dimension(w, h/2));
        botoRegistre = new JButton(UNIRSE);
        botoIniciSessio = new JButton(ACCEDIR);
        setLayout(new GridLayout(2,1));
        add(titol);
        botons.add(botoRegistre);
        botons.add(botoIniciSessio);
        add(botons);

    }

    public void registerController(ControllerAction c) {

        this.botoRegistre.setActionCommand(UNIRSE);
        this.botoRegistre.addActionListener(c);
        this.botoIniciSessio.setActionCommand(ACCEDIR);
        this.botoIniciSessio.addActionListener(c);

    }

    @Override
    public void registerMouse(ControllerMouse c) {

    }

}
