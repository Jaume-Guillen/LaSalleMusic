package com.company.Model;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Llista que es troba dins el programa.
 */

public class LlistaReproduccio implements Serializable {

    int id_llistaReproduccio;
    String nom;
    String nom_usuari;
    ArrayList<Canco> cancons = new ArrayList<Canco>();
    static final long serialVersionUID = 43L;

    /**
     * Constructor de la llista.
     * @param id_llistaReproduccio ID de la llista.
     * @param nom Nom de la llista.
     * @param nom_usuari Nom de l'usuari que ha creat la llista.
     */

    public LlistaReproduccio(int id_llistaReproduccio, String nom, String nom_usuari) {
        this.id_llistaReproduccio = id_llistaReproduccio;
        this.nom = nom;
        this.nom_usuari = nom_usuari;
    }

    public int getId_llistaReproduccio() {
        return id_llistaReproduccio;
    }

    public void setId_llistaReproduccio(int id_llistaReproduccio) {
        this.id_llistaReproduccio = id_llistaReproduccio;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getNom_usuari() {
        return nom_usuari;
    }

    public void setNom_usuari(String nom_usuari) {
        this.nom_usuari = nom_usuari;
    }

    public ArrayList<Canco> getCancons() {
        return cancons;
    }

    public void setCancons(ArrayList<Canco> cancons) {
        this.cancons = cancons;
    }
}
