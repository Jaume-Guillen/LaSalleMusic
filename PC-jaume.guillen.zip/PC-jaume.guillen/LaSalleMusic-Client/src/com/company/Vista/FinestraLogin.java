package com.company.Vista;

import com.company.Controlador.ControllerAction;
import com.company.Controlador.ControllerMouse;

import javax.swing.*;
import java.awt.*;

/**
 * Finestra des d'on l'usuari pot entrar a un compte ja creat.
 */

public class FinestraLogin extends JFrame implements Finestra{

    public final static String LOGIN = "LOG IN";
    public final static String BACK = "Tornar enrera";
    private JButton botoIniciSessio;
    JButton botoEnrera;
    private JTextField nom_usuari_tf;
    private JTextField contrasenya_tf;
    private JPanel textFields;
    JLabel errorContrasenya;

    /**
     * Inicialitza la finestra i la mostra.
     * @param w Amplada de la finestra.
     * @param h Llargada de la finestra.
     */

    public FinestraLogin(int w, int h){

        setSize(new Dimension(w, h));
        setTitle("LaSalle Music");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        textFields = new JPanel();
        textFields.setLayout(null);
        textFields.setBounds(0, h/4, w, 3*h/4);
        textFields.setMaximumSize(new Dimension(w, 3*h/4));
        botoIniciSessio = new JButton(LOGIN);
        nom_usuari_tf = new JTextField();
        nom_usuari_tf.setMaximumSize(new Dimension(w/3, 3*h/16));
        contrasenya_tf = new JPasswordField();
        errorContrasenya = new JLabel("Error! Nom d'usuari o contrasenya incorrecta!");
        errorContrasenya.setBounds(w/50, h/10, w - w/50, h/4);
        errorContrasenya.setVisible(false);
        textFields.add(errorContrasenya);
        JLabel nom_usuari_l = new JLabel("Nom usuari: ");
        JLabel contrasenya_l = new JLabel("Contrasenya: ");
        nom_usuari_l.setBounds(w/2 - w/10, h/4, w/2, h/16);
        textFields.add(nom_usuari_l);
        textFields.add(nom_usuari_tf);
        nom_usuari_tf.setBounds(w/2 + w/100, h/4, w/2 - w/10, h/16);
        contrasenya_l.setBounds(w/2 - w/9 - w/1000, h/4 + h/8, w/2 - w/5, h/16);
        textFields.add(contrasenya_l);
        contrasenya_tf.setBounds(w/2 + w/100, h/4 + h/8, w/2 - w/10, h/16);
        textFields.add(contrasenya_tf);
        textFields.add(botoIniciSessio);
        botoEnrera = new JButton(BACK);
        botoEnrera.setBounds(3*w/4 - w/8, h/2 + h/4, w/4, h/16);
        textFields.add(botoEnrera);
        add(textFields);
        botoIniciSessio.setBounds(w/4 - w/8, h/2 + h/4, w/4, h/16);

    }

    @Override
    public void registerController(ControllerAction c) {

        this.botoIniciSessio.setActionCommand(LOGIN);
        this.botoIniciSessio.addActionListener(c);
        this.botoEnrera.setActionCommand(BACK);
        this.botoEnrera.addActionListener(c);

    }

    @Override
    public void registerMouse(ControllerMouse c) {

    }

    public String getNomUsuari(){

        return nom_usuari_tf.getText();

    }

    public String getContrasenya(){

        return contrasenya_tf.getText();

    }

    /**
     * Mostra un missatge d'error per pantalla.
     */

    public void contrasenyaError(){

        contrasenya_tf.setText("");
        errorContrasenya.setForeground(Color.RED);
        errorContrasenya.setVisible(true);
        textFields.validate();
        textFields.repaint();

    }
}
