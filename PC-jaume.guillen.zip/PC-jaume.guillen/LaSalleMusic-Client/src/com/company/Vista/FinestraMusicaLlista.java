package com.company.Vista;

import com.company.Controlador.ControllerAction;
import com.company.Controlador.ControllerMouse;
import com.company.Controlador.ControllerWindow;
import com.company.Model.Canco;
import com.company.Model.MP3Reproducer;
import com.company.Model.Usuari;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.LinkedList;

/**
 * Finestra que mostra la musica d'una llista.
 */

public class FinestraMusicaLlista extends JFrame implements Finestra{

    public final static String TORNAR = "Tornar";
    public final static String BUCLE = "Bucle";
    public final static String NOBUCLE = "No bucle";
    public final static String BUCLELLISTA = "Bucle llista";
    public final static String ELIMINAR = "Eliminar";
    public final static String STRING1 = "1";
    public final static String STRING2 = "2";
    public final static String STRING3 = "3";
    public final static String STRING4 = "4";
    public final static String STRING5 = "5";
    public final static String ELIMINARCANCO = "ELIMINARCANCO";
    JTable taula;
    JPopupMenu popup = new JPopupMenu("Eliminar");
    JMenuItem JEliminar = new JMenuItem(ELIMINAR);
    JMenuItem JCancelar = new JMenuItem("Cancelar");
    JButton JbLlistes = new JButton(TORNAR);
    JButton JbBucle = new JButton(BUCLE);
    JPanel JpButtons = new JPanel();
    ButtonGroup group;
    JRadioButton button1 = new JRadioButton(STRING1);
    JRadioButton button2 = new JRadioButton(STRING2);
    JRadioButton button3 = new JRadioButton(STRING3);
    JRadioButton button4 = new JRadioButton(STRING4);
    JRadioButton button5 = new JRadioButton(STRING5);

    int rowindex = -1;

    /**
     * Inicialitza la finestra i la mostra.
     * @param w Amplada de la finestra.
     * @param h Llargada de la finestra.
     * @param cancons Llista de cancons de la llista.
     */

    public FinestraMusicaLlista(int w, int h, LinkedList<Canco> cancons){

        setSize(new Dimension(w, h));
        setTitle("LaSalle Music");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        String[] columnNames = {"Nom canco", "Genere", "Album", "Artista", "Numero estrelles", "Numero reproduccions"};
        Object[][] data = new Object[cancons.size()][6];

        for(int i = 0; i < cancons.size(); i++){

            data[i][0] = cancons.get(i).getNom();
            data[i][1] = cancons.get(i).getGenere();
            data[i][2] = cancons.get(i).getAlbum();
            data[i][3] = cancons.get(i).getArtista();
            data[i][4] = cancons.get(i).getEstrelles();
            data[i][5] = cancons.get(i).getReproduccions_totals();

        }

        group = new ButtonGroup();

        group.add(button1);
        group.add(button2);
        group.add(button3);
        group.add(button4);
        group.add(button5);
        button1.setSelected(false);
        button2.setSelected(false);
        button3.setSelected(false);
        button4.setSelected(false);
        button5.setSelected(false);

        button1.setVisible(false);
        button2.setVisible(false);
        button3.setVisible(false);
        button4.setVisible(false);
        button5.setVisible(false);
        JbBucle.setVisible(false);

        taula = new JTable(data, columnNames);


        JpButtons.setBounds(0, h - h/8, w, h/16);
        JbLlistes.setBounds(w/4 - w/16, h - h/8, w/8, h/16);
        JpButtons.add(JbLlistes);
        JbBucle.setBounds(3*w/4 - w/16, h - h/8, w/8, h/16);
        JpButtons.add(JbBucle);
        button1.setBounds(w/20, h-h/8, w/10, h/16);
        button1.setLabel("1");
        JpButtons.add(button1);

        button2.setBounds(2*w/20, h-h/8, w/10, h/16);
        button2.setLabel("2");
        JpButtons.add(button2);

        button3.setBounds(3*w/20, h-h/8, w/10, h/16);
        button3.setLabel("3");
        JpButtons.add(button3);

        button4.setBounds(4*w/20, h-h/8, w/10, h/16);
        button4.setLabel("4");
        JpButtons.add(button4);

        button5.setBounds(5*w/20, h-h/8, w/10, h/16);
        button5.setLabel("5");
        JpButtons.add(button5);

        popup.add(JEliminar);
        popup.add(JCancelar);

        this.add(new JScrollPane(taula));
        this.add(JpButtons, BorderLayout.SOUTH);

    }

    public void registerMouse(ControllerMouse c){

        taula.addMouseListener(c);


    }

    public void registerWindow(ControllerWindow c){

        this.addWindowListener(c);

    }

    public void registerController(ControllerAction c){

        JEliminar.setActionCommand("ELIMINARCANCO");
        this.JEliminar.addActionListener(c);

        button1.setActionCommand(STRING1);
        this.button1.addActionListener(c);
        button2.setActionCommand(STRING2);
        this.button2.addActionListener(c);
        button3.setActionCommand(STRING3);
        this.button3.addActionListener(c);
        button4.setActionCommand(STRING4);
        this.button4.addActionListener(c);
        button5.setActionCommand(STRING5);
        this.button5.addActionListener(c);
        JbBucle.setActionCommand(BUCLE);
        this.JbBucle.addActionListener(c);


        this.JbLlistes.setActionCommand(TORNAR);
        this.JbLlistes.addActionListener(c);



    }

    public void setRowindex(int rowindex) {
        this.rowindex = rowindex;
    }

    public int getRowindex() {
        return rowindex;
    }

    public JButton getJbBucle() {
        return JbBucle;
    }

    public JTable getTaula() {
        return taula;
    }

    public JRadioButton getButton1() {
        return button1;
    }

    public JRadioButton getButton2() {
        return button2;
    }

    public JRadioButton getButton3() {
        return button3;
    }

    public JRadioButton getButton4() {
        return button4;
    }

    public JRadioButton getButton5() {
        return button5;
    }

    public JPopupMenu getPopup() {
        return popup;
    }

    public JMenuItem getJEliminar() {
        return JEliminar;
    }

    public JMenuItem getJCancelar() {
        return JCancelar;
    }

    public ButtonGroup getGroup() {
        return group;
    }
}