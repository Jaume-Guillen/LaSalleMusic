package com.company.Model;

/**
 * Classe auxiliar per llegir el JSON.
 */

public class JSONClass {
    private float port;
    private String ip;


    // Getter Methods

    public String getIp() {
        return ip;
    }

    public float getPort() {
        return port;
    }

    // Setter Methods

    public void setIp(String ip) {
        this.ip = ip;
    }

    public void setPort(float port) {
        this.port = port;
    }
}
