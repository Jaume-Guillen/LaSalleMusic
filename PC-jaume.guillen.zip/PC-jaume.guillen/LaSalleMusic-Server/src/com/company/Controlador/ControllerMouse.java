package com.company.Controlador;

import com.company.Vista.Finestra;
import com.company.Vista.FinestraCancons;
import com.company.Vista.FinestraUsuaris;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 * Controlador del mouse que gestiona els events que passen quan l'usuari interacciona amb les taules de l'aplicacio.
 */

public class ControllerMouse extends MouseAdapter implements MouseListener{

    Finestra f;

    /**
     * Constructor del controlador del mouse.
     * @param f Finestra gestionada per aquest controlador.
     */

    public ControllerMouse(Finestra f){

        this.f = f;

    }
    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

        if(f.getClass().getSimpleName().equals("FinestraCancons")) {

            FinestraCancons aux = (FinestraCancons)f;
            int r = aux.getTaula().rowAtPoint(e.getPoint());
            if (r >= 0 && r < aux.getTaula().getRowCount()) {
                aux.getTaula().setRowSelectionInterval(r, r);
            } else {
                aux.getTaula().clearSelection();
            }

            aux.setRowindex(aux.getTaula().getSelectedRow());

            if(SwingUtilities.isRightMouseButton(e)) {
                if (aux.getRowindex() < 0)
                    return;
                aux.getPopup().show(e.getComponent(), e.getX(), e.getY());
            }
        }

        if(f.getClass().getSimpleName().equals("FinestraUsuaris")) {

            FinestraUsuaris aux = (FinestraUsuaris)f;
            int r = aux.getTaula().rowAtPoint(e.getPoint());
            if (r >= 0 && r < aux.getTaula().getRowCount()) {
                aux.getTaula().setRowSelectionInterval(r, r);
            } else {
                aux.getTaula().clearSelection();
            }

            aux.setRowindex(aux.getTaula().getSelectedRow());

            if(SwingUtilities.isRightMouseButton(e)) {
                if (aux.getRowindex() < 0)
                    return;
                aux.getPopup().show(e.getComponent(), e.getX(), e.getY());
            }
        }

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
