package com.company.Vista;

import com.company.Controlador.ControllerAction;
import com.company.Controlador.ControllerMouse;
import com.company.Model.Canco;
import com.company.Model.LlistaReproduccio;
import com.company.Model.Usuari;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.LinkedList;

/**
 * Finestra que mostra les llistes de reproduccio de l'usuari.
 */

public class FinestraLlistesReproduccio extends JFrame implements Finestra{

    public final static String MENU = "MENU";
    public final static String ADDLIST = "Afegir Llista";
    public final static String ELIMINALLISTA = "Elimina llista";
    JTable taula;
    JPopupMenu popup = new JPopupMenu("Eliminar");
    JMenuItem JEliminar = new JMenuItem("Eliminar");
    JMenuItem JCancelar = new JMenuItem("Cancelar");
    JButton JbEnrera = new JButton(MENU);
    JButton JbAfegir = new JButton(ADDLIST);
    JPanel JpButtons = new JPanel();

    int rowindex = -1;

    /**
     * Inicialitza la finestra i la mostra.
     * @param w Amplada de la finestra.
     * @param h Llargada de la finestra.
     * @param llistes Llistes de l'usuari.
     * @param u Usuari registrat en aquest moment.
     */

    public FinestraLlistesReproduccio(int w, int h, LinkedList<LlistaReproduccio> llistes, Usuari u){

        setSize(new Dimension(w, h));
        setTitle("LaSalle Music");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        String[] columnNames = {"Nom llista"};
        Object[][] data = new Object[llistes.size()][4];

        for(int i = 0; i < llistes.size(); i++){

            if(u.getNom_usuari().equals(llistes.get(i).getNom_usuari())) {

                data[i][0] = llistes.get(i).getNom();

            }

        }

        taula = new JTable(data, columnNames);

        taula.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);




        JbEnrera.setBounds(w/2 - w/16, h - h/8, w/8, h/16);
        JpButtons.setBounds(0, h - h/8, w, h/16);
        JpButtons.add(JbEnrera);
        JbAfegir.setBounds(w/4 - w/16, h - h/8, w/8, h/16);
        JpButtons.add(JbAfegir);
        popup.add(JEliminar);
        popup.add(JCancelar);
        this.add(new JScrollPane(taula));
        this.add(JpButtons, BorderLayout.SOUTH);

    }

    public void registerController(ControllerAction c){

        this.JEliminar.setActionCommand(ELIMINALLISTA);
        this.JEliminar.addActionListener(c);

        this.JbEnrera.setActionCommand(MENU);
        this.JbEnrera.addActionListener(c);

        this.JbAfegir.setActionCommand(ADDLIST);
        this.JbAfegir.addActionListener(c);

    }

    @Override
    public void registerMouse(ControllerMouse c) {

        taula.addMouseListener(c);

    }

    public static String getMENU() {
        return MENU;
    }

    public static String getADDLIST() {
        return ADDLIST;
    }

    public JTable getTaula() {
        return taula;
    }

    public void setTaula(JTable taula) {
        this.taula = taula;
    }

    public JPopupMenu getPopup() {
        return popup;
    }

    public void setPopup(JPopupMenu popup) {
        this.popup = popup;
    }

    public JMenuItem getJEliminar() {
        return JEliminar;
    }

    public void setJEliminar(JMenuItem JEliminar) {
        this.JEliminar = JEliminar;
    }

    public JMenuItem getJCancelar() {
        return JCancelar;
    }

    public void setJCancelar(JMenuItem JCancelar) {
        this.JCancelar = JCancelar;
    }

    public JButton getJbEnrera() {
        return JbEnrera;
    }

    public void setJbEnrera(JButton jbEnrera) {
        JbEnrera = jbEnrera;
    }

    public JButton getJbAfegir() {
        return JbAfegir;
    }

    public void setJbAfegir(JButton jbAfegir) {
        JbAfegir = jbAfegir;
    }

    public JPanel getJpButtons() {
        return JpButtons;
    }

    public void setJpButtons(JPanel jpButtons) {
        JpButtons = jpButtons;
    }

    public int getRowindex() {
        return rowindex;
    }

    public void setRowindex(int rowindex) {
        this.rowindex = rowindex;
    }
}
