package com.company.Model;

import jaco.mp3.player.MP3Player;
import javazoom.jl.player.advanced.AdvancedPlayer;

import java.io.File;
import java.io.FileInputStream;

/**
 * Classe que ens permet reproduir fitxers mp3.
 */

public class MP3Reproducer extends Thread{

    private String path_canco;
    private boolean playing = false;
    MP3Player playMP3;
    public boolean change = false;
    private int bucle = 0;

    /**
     * Constructor de la classe.
     * @param path_canco Path de la canco que volem reproduir.
     */

    public MP3Reproducer(String path_canco){

        this.path_canco = path_canco;
        this.bucle = 0;

    }

    /**
     * El programa corre en paralel per reproduir una canco.
     */

    public void run() {
        try {

                //playMP3 = new MP3Player(new File(path_canco));
                //playMP3.play();
            System.out.println(("a"));

                while(true){

                    if(change){

                        System.out.println(("b"));


                    }

                }

        }catch(Exception e){

            e.printStackTrace();

        }
    }

    public String getPath_canco() {
        return path_canco;
    }

    public MP3Player getPlayMP3() {
        return playMP3;
    }

    public void setPlaying(boolean playing) {
        this.playing = playing;
    }

    public void setPath_canco(String path_canco) {
        this.path_canco = path_canco;
        change = true;
        playMP3 = new MP3Player(new File(path_canco));
        playMP3.play();
        change = false;
    }

    public void setActualSong(String path_canco){

        this.path_canco = path_canco;

    }

    public int getBucle() {
        return bucle;
    }

    public void setBucle(int bucle) {
        this.bucle = bucle;
    }
}
