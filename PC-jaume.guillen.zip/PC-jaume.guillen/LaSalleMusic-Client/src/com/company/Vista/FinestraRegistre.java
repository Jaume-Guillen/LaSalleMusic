package com.company.Vista;

import com.company.Controlador.ControllerAction;
import com.company.Controlador.ControllerMouse;

import javax.swing.*;
import java.awt.*;

/**
 * Finestra que permet a l'usuari registrarse al sistema.
 */
public class FinestraRegistre extends JFrame implements Finestra{

    public final static String REGISTER = "REGISTRAR-SE";
    public final static String BACK = "Tornar enrera";
    JButton botoRegistre;
    JButton botoEnrera;
    JTextField nom_usuari_tf;
    JPasswordField contrasenya_tf;
    JPasswordField repetir_tf;
    JTextField email_tf;
    JLabel errorContrasenya;
    JPanel textFields;

    /**
     * Inicialitza la finestra i la mostra.
     * @param w Amplada de la finestra.
     * @param h Llargada de la finestra.
     */

    public FinestraRegistre(int w, int h){

        setSize(new Dimension(w, h));
        setTitle("LaSalle Music");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        textFields = new JPanel();
        textFields.setLayout(null);
        textFields.setBounds(0, 0, w, h);
        textFields.setMaximumSize(new Dimension(w, 3*h/4));
        nom_usuari_tf = new JTextField();
        nom_usuari_tf.setMaximumSize(new Dimension(w/3, 3*h/16));
        contrasenya_tf = new JPasswordField();
        repetir_tf = new JPasswordField();
        email_tf = new JTextField();
        errorContrasenya = new JLabel("Error! La contrasenya ha de tenir 6 o mes caracters, algun numero i tant majuscules com minuscules.");
        errorContrasenya.setBounds(w/50, h/10, w - w/50, h/4);
        errorContrasenya.setVisible(false);
        textFields.add(errorContrasenya);
        JLabel nom_usuari_l = new JLabel("Nom usuari: ");
        JLabel contrasenya_l = new JLabel("Contrasenya: ");
        JLabel email_l = new JLabel("E-mail: ");
        JLabel repetir_l = new JLabel("Repetir contrasenya: ");
        nom_usuari_l.setBounds(w/2 - w/10, h/4, w/2, h/16);
        textFields.add(nom_usuari_l);
        textFields.add(nom_usuari_tf);
        nom_usuari_tf.setBounds(w/2 + w/100, h/4, w/2 - w/10, h/16);
        contrasenya_l.setBounds(w/2 - w/9 - w/1000, h/4 + h/8, w/2 - w/5, h/16);
        textFields.add(contrasenya_l);
        contrasenya_tf.setBounds(w/2 + w/100, h/4 + h/8, w/2 - w/10, h/16);
        repetir_l.setBounds(w/2 - w/6 - w/100, 5*h/8, w/2 - w/5, h/16);
        repetir_tf.setBounds(w/2 + w/80, 5*h/8, w/2 - w/10, h/16);
        textFields.add(contrasenya_tf);
        textFields.add(repetir_l);
        textFields.add(repetir_tf);
        email_tf.setBounds(w/2 + w/100, h/2, w/2 - w/10, h/16);
        email_l.setBounds(w/2 - w/18, h/2, w/2 - w/5, h/16);
        textFields.add(email_l);
        textFields.add(email_tf);
        botoRegistre = new JButton(REGISTER);
        botoRegistre.setBounds(w/4 - w/8, h/2 + h/4, w/4, h/16);
        textFields.add(botoRegistre);
        botoEnrera = new JButton(BACK);
        botoEnrera.setBounds(3*w/4 - w/8, h/2 + h/4, w/4, h/16);
        textFields.add(botoEnrera);

        add(textFields);

    }

    @Override
    public void registerController(ControllerAction c) {

        this.botoRegistre.setActionCommand(REGISTER);
        this.botoRegistre.addActionListener(c);
        this.botoEnrera.setActionCommand(BACK);
        this.botoEnrera.addActionListener(c);

    }

    @Override
    public void registerMouse(ControllerMouse c) {

    }

    public String getNomUsuari(){

        return nom_usuari_tf.getText();

    }

    public String getContrasenya(){

        return contrasenya_tf.getText();

    }

    public String getEmail(){

        return email_tf.getText();

    }

    public String getRepetir(){

        return repetir_tf.getText();

    }

    /**
     * Mostra un error per pantalla.
     * @param text Missatge d'error que es vol mostrar.
     */

    public void contrasenyaError(String text){

        errorContrasenya.setText(text);
        contrasenya_tf.setText("");
        repetir_tf.setText("");
        errorContrasenya.setForeground(Color.RED);
        errorContrasenya.setVisible(true);
        textFields.validate();
        textFields.repaint();

    }
}

