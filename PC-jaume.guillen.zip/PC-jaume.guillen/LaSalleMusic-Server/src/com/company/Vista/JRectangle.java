package com.company.Vista;

import javax.swing.*;
import java.awt.*;

/**
 * Rectangle utilitzat en la finestra d'estadistiques.
 */

public class JRectangle extends JComponent {

    private int x;
    private int y;
    private int width;
    private int height;

    /**
     *Constructor del JRectangle.
     * @param x On comenca el rectangle horitzontalment.
     * @param y On comenca el rectangle verticalment.
     * @param width Amplada del rectangle.
     * @param height Alcada del rectangle.
     */
    public JRectangle(int x, int y, int width, int height){
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawRect(x, y, width, height);
        g.setColor(Color.RED);
        g.fillRect(x, y, width, height);
    }

}
