package com.company.Vista;

import com.company.Controlador.ControllerAction;
import com.company.Controlador.ControllerMouse;
import com.company.Model.Usuari;

import javax.swing.*;
import javax.swing.filechooser.FileFilter;
import java.awt.*;
import java.io.File;

/**
 * Finestra des de la que el usuari pot afegir una llista al servidor.
 */

public class FinestraAfegirLlista extends JFrame implements Finestra{

    public final static String MENULLISTES = "TORNAR ENRERA";
    public final static String AFEGIR = "AFEGEIX LLISTA";
    JButton botoEnrera;
    JButton botoAfegir;
    JTextField nom_tf;
    JLabel errorFitxer;
    JPanel textFields;
    JFileChooser fc = new JFileChooser();
    String path = "";

    /**
     * Inicialitza la finestra.
     * @param w Amplada de la finestra.
     * @param h Llargada de la finestra.
     */

    public FinestraAfegirLlista(int w, int h){

        setSize(new Dimension(w, h));
        setTitle("LaSalle Music");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        textFields = new JPanel();
        textFields.setLayout(null);
        textFields.setBounds(0, 0, w, h);
        textFields.setMaximumSize(new Dimension(w, 3*h/4));
        nom_tf = new JTextField("");
        nom_tf.setMaximumSize(new Dimension(w/3, 3*h/16));
        errorFitxer = new JLabel("Error! Algun camp esta buit!.");
        errorFitxer.setBounds(w/50, h/10, w - w/50, h/4);
        errorFitxer.setVisible(false);
        textFields.add(errorFitxer);
        JLabel nom__l = new JLabel("Nom: ");
        nom__l.setBounds(w/2 - w/10, h/4, w/2, h/16);
        textFields.add(nom__l);
        textFields.add(nom_tf);
        nom_tf.setBounds(w/2 + w/100, h/4, w/2 - w/10, h/16);
        botoEnrera = new JButton(MENULLISTES);
        botoEnrera.setBounds(3*w/4 - w/8, h/2 + h/4, w/4, h/16);
        textFields.add(botoEnrera);
        botoAfegir = new JButton(AFEGIR);
        botoAfegir.setBounds(w/2 - w/8, h/2 + h/4, w/4, h/16);
        textFields.add(botoAfegir);
        fc.setFileFilter(new FileFilter() {
            @Override
            public boolean accept(File f) {
                if (f.isDirectory()) {
                    return true;
                } else {
                    String filename = f.getName().toLowerCase();
                    return filename.endsWith(".mp3") || filename.endsWith(".wav") ;
                }
            }

            @Override
            public String getDescription() {
                return "MP3 files (.mp3) or WAV files (.wav)";
            }
        });

        add(textFields);

    }

    @Override
    public void registerController(ControllerAction c) {

        this.botoEnrera.setActionCommand(MENULLISTES);
        this.botoEnrera.addActionListener(c);
        this.botoAfegir.setActionCommand(AFEGIR);
        this.botoAfegir.addActionListener(c);

    }

    @Override
    public void registerMouse(ControllerMouse c) {

    }

    public String getNom(){

        return nom_tf.getText();

    }

    /**
     * Mostra per pantalla un missatge d'error.
     * @param text Missatge d'error.
     */

    public void afegirError(String text){

        errorFitxer.setText(text);
        errorFitxer.setForeground(Color.RED);
        errorFitxer.setVisible(true);
        textFields.validate();
        textFields.repaint();

    }

}
