package com.company;

import com.company.Controlador.ControllerAction;
import com.company.Model.Config;
import com.company.Model.Manager;
import com.company.Model.Usuari;
import com.company.Network.Server;
import com.company.Vista.FinestraInici;
import com.company.Vista.FinestraMenu;

public class Main {

    public static void main(String[] args) {
        try {

            Config conf;

            conf = Config.getInstance();

            FinestraMenu fm = new FinestraMenu(640, 480);

            Manager m = new Manager();

            ControllerAction c = new ControllerAction(fm, m);

            fm.registerController(c);

            fm.setVisible(true);

            Server s = new Server(conf.getPort_comunicacio());
            s.start();

        }catch(Exception e){

            e.printStackTrace();

        }
    }
}
