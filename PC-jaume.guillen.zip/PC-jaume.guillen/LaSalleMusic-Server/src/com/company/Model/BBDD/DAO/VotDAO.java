package com.company.Model.BBDD.DAO;

import com.company.Model.Usuari;
import com.company.Model.Vot;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

/**
 * Classe que ens permet gestionar la taula Vot de la base de dades.
 */

public class VotDAO {

    /**
     * Constructor buit de VotDAO.
     */

    public VotDAO() {



    }

    /**
     * Afegeix un vot a la base de dades.
     * @param v Vot que volem afegir.
     */

    public void addVot(Vot v) {

        DBConnector.getInstance().insertQuery("INSERT INTO Vot(nom_usuari, path_canco, estrelles) VALUES ('"+v.getNom_usuari()+"', '"+v.getPath_canco()+"', '"+v.getEstrelles()+"');");

    }

    /**
     * Obte tots els vots de la base de dades.
     * @return LinkedList amb tots els vots.
     */

    public LinkedList<Vot> getAllVots() {
        LinkedList<Vot> vots = new LinkedList<>();
        ResultSet resultat = DBConnector.getInstance().selectQuery("SELECT nom_usuari, path_canco, estrelles FROM Vot;");
        try{
            while(resultat.next()){
                String nom_usuari = resultat.getString("nom_usuari");
                String path_canco = resultat.getString("path_canco");
                int estrelles = resultat.getInt("estrelles");
                vots.add(new Vot(nom_usuari, path_canco, estrelles));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return vots;
    }

    /**
     * Actualitza un vot de la base de dades.
     * @param v Vot que volem actualitzar.
     */

    public void updateVot(Vot v){

        DBConnector.getInstance().updateQuery("UPDATE Vot SET estrelles = "+ v.getEstrelles() + " WHERE path_canco LIKE '" + v.getPath_canco() + "' AND nom_usuari LIKE '"+v.getNom_usuari()+"';");

    }

    /**
     * Elimina un vot de la base de dades.
     * @param nom_usuari FK de l'usuari que ha fet el vot que volem eliminar.
     * @param path_canco FK de la canco de la qual volem eliminar un vot.
     */

    public void deleteVot(String nom_usuari, String path_canco) {
        DBConnector.getInstance().deleteQuery("DELETE FROM Usuari WHERE nom_usuari LIKE '"+nom_usuari+"' AND id_canco LIKE "+path_canco+";");
    }
}
