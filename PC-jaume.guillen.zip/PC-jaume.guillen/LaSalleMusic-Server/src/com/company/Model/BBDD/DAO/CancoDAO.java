package com.company.Model.BBDD.DAO;

import com.company.Model.Canco;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

/**
 * Classe que gestiona la taula Canco de la base de dades.
 */

public class CancoDAO {

    /**
     * Constructor buit de CancoDAO.
     */

    public CancoDAO() {



    }

    /**
     * Afegeix una canco a la base de dades.
     * @param c Canco a afegir.
     */

    public void addCanco(Canco c) {

        DBConnector.getInstance().insertQuery("INSERT INTO Canco(path_canco, nom, genere, album, artista, estrelles, reproduccions_totals) VALUES ('"+c.getPath_canco()+"', '"+c.getNom()+"', '"+c.getGenere()+"', '"+c.getAlbum()+"', '"+c.getArtista()+"', '"+c.getEstrelles()+"', '"+c.getReproduccions_totals()+"');");

    }

    /**
     * Obte totes les cancons de la base de dades.
     * @return Retorna una LinkedList amb totes les cancons.
     */

    public LinkedList<Canco> getAllCancons() {
        LinkedList<Canco> cancons = new LinkedList<>();
        ResultSet resultat = DBConnector.getInstance().selectQuery("SELECT path_canco, nom, genere, album, artista, estrelles, reproduccions_totals FROM Canco;");
        try{
            while(resultat.next()){
                String path_canco = resultat.getString("path_canco");
                String nom = resultat.getString("nom");
                String genere = resultat.getString("genere");
                String album = resultat.getString("album");
                String artista = resultat.getString("artista");
                float estrelles = resultat.getFloat("estrelles");
                int reproduccions_totals = resultat.getInt("reproduccions_totals");
                cancons.add(new Canco(path_canco, nom, genere, album, artista, estrelles, reproduccions_totals));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cancons;
    }

    /**
     * Obte totes les cancons d'una llista.
     * @param fk FK de la llista de la que volem totes les cancons.
     * @return Una LinkedList amb totes les cancons.
     */

    public LinkedList<Canco> getCanconsLlista(int fk) {
        LinkedList<Canco> cancons = new LinkedList<>();
        ResultSet resultat = DBConnector.getInstance().selectQuery("SELECT c.path_canco, c.nom, c.genere, c.album, c.artista, c.estrelles, c.reproduccions_totals FROM Canco AS c, CancoLlista AS cl WHERE c.path_canco LIKE cl.path_canco AND cl.id_llista = " + fk + ";");
        try{
            while(resultat.next()){
                String path_canco = resultat.getString("path_canco");
                String nom = resultat.getString("nom");
                String genere = resultat.getString("genere");
                String album = resultat.getString("album");
                String artista = resultat.getString("artista");
                float estrelles = resultat.getFloat("estrelles");
                int reproduccions_totals = resultat.getInt("reproduccions_totals");
                cancons.add(new Canco(path_canco, nom, genere, album, artista, estrelles, reproduccions_totals));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cancons;
    }

    /**
     * Obte el top 10 de cancons.
     * @return Una LinkedList amb totes les cancons ordenades.
     */

    public LinkedList<Canco> getCanconsOrdenat() {
        LinkedList<Canco> cancons = new LinkedList<>();
        ResultSet resultat = DBConnector.getInstance().selectQuery("SELECT path_canco, nom, genere, album, artista, estrelles, reproduccions_totals FROM Canco AS c ORDER BY reproduccions_totals DESC LIMIT 10;");
        try{
            while(resultat.next()){
                String path_canco = resultat.getString("path_canco");
                String nom = resultat.getString("nom");
                String genere = resultat.getString("genere");
                String album = resultat.getString("album");
                String artista = resultat.getString("artista");
                float estrelles = resultat.getFloat("estrelles");
                int reproduccions_totals = resultat.getInt("reproduccions_totals");
                cancons.add(new Canco(path_canco, nom, genere, album, artista, estrelles, reproduccions_totals));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cancons;
    }

    /**
     * Elimina una canco de la base de dades.
     * @param path_canco FK de la canco a eliminar.
     */

    public void deleteCanco(String path_canco) {
        DBConnector.getInstance().deleteQuery("DELETE FROM Canco WHERE path_canco LIKE '"+path_canco+"';");
    }

    /**
     * Incrementa en 1 les visualitzacions d'una canco.
     * @param fk FK de la canco de la que volem incrementar les visualitzacions.
     */

    public void incrementaVisualitzacions(String fk){

        DBConnector.getInstance().updateQuery("UPDATE Canco SET reproduccions_totals = reproduccions_totals + 1 WHERE path_canco LIKE '" + fk + "';");

    }

    /**
     * Calcula la mitjana d'estrelles d'una canco.
     * @param fk FK de la canco de la que calcular les estrelles.
     */

    public void calculaEstrelles(String fk){

        DBConnector.getInstance().updateQuery("UPDATE Canco SET estrelles = (SELECT AVG(v.estrelles) FROM Vot AS v WHERE v.path_canco LIKE '"+fk+"' GROUP BY v.path_canco) WHERE path_canco LIKE '"+fk+"';");

    }

}
