package com.company.Vista;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

/**
 * Conjunt de JRectangles.
 */

class JRectangles extends JPanel {

    private ArrayList<Rectangle> rectangles = new ArrayList<Rectangle>();

    /**
     * Afegeix un rectangle a la LinkedList.
     * @param x On comenca el rectangle horitzontalment.
     * @param y On comenca el rectangle verticalment.
     * @param width Amplada del rectangle.
     * @param height Alcada del rectangle.
     */

    public void addRectangle(int x, int y, int width, int height) {
        Rectangle rect = new Rectangle(x, y, width, height);
        rectangles.add(rect);
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(100, 100);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        for (Rectangle rect : rectangles) {
            g2.draw(rect);
            g2.setColor(Color.RED);
            g2.fill(rect);
        }
    }

}