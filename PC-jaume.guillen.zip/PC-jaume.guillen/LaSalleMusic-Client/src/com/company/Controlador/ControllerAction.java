package com.company.Controlador;

import com.company.Model.*;
import com.company.Network.Client;
import com.company.Vista.*;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;

/**
 * Controlador que estiona totes les accions realitzades amb els diversos botons.
 */

public class ControllerAction implements ActionListener {

    Finestra f;
    Client cl;
    MP3Reproducer mp3;
    Usuari u;
    LinkedList<LlistaReproduccio> llistes;
    LinkedList<Canco> cancons;
    int id_llista;

    /**
     * Constructor del controlador.
     * @param f Finestra activa en aquest moment.
     * @param cl Client del programa.
     */

    public ControllerAction(Finestra f, Client cl){

        this.f = f;
        this.cl = cl;

    }


    @Override
    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();
        ControllerAction cReg;
        ControllerAction cLog;
        ControllerAction cUn;
        ControllerAction cIn;
        ControllerMouse cm;
        MP3Reproducer mp3;
        ControllerWindow cw;

        switch(action){

            case FinestraInici.UNIRSE:
                FinestraRegistre fr = new FinestraRegistre(640,420);
                cReg = new ControllerAction(fr, cl);
                fr.registerController(cReg);
                fr.setVisible(true);
                ((JFrame) f).dispose();
                break;

            case FinestraInici.ACCEDIR:
                FinestraLogin fl = new FinestraLogin(640,420);
                cLog = new ControllerAction(fl, cl);
                fl.registerController(cLog);
                fl.setVisible(true);
                ((JFrame) f).dispose();
                break;

            case FinestraLogin.LOGIN:
                LinkedList<Usuari> usuaris = (LinkedList<Usuari>) cl.sendMessage("RU");
                String nom = ((FinestraLogin) f).getNomUsuari();
                String contrasenya = ((FinestraLogin) f).getContrasenya();
                boolean trobat = false;
                for(int i = 0; i < usuaris.size(); i++){

                    //System.out.println(usuaris.get(i).getContrasenya());

                    if(nom.equals(usuaris.get(i).getNom_usuari()) && contrasenya.equals(usuaris.get(i).getContrasenya())){

                        Usuari us = new Usuari();
                        String acces = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
                        us.RegistraUsuari(nom, contrasenya, usuaris.get(i).getEmail(), usuaris.get(i).getData_registre(), acces);
                        cl.sendMessage("MA-" + nom);
                        LinkedList<Canco> cs = (LinkedList<Canco>) cl.sendMessage("RC");
                        LinkedList<LlistaReproduccio> lssss = (LinkedList<LlistaReproduccio>) cl.sendMessage("RL");
                        FinestraMusicaDisponible fm = new FinestraMusicaDisponible(640, 420, cs, lssss);
                        mp3 = new MP3Reproducer("");
                        cUn = new ControllerAction(fm, cl);
                        cUn.setMp3(mp3);
                        cUn.setU(usuaris.get(i));
                        cUn.setLlistes(lssss);
                        cUn.setCancons(cs);
                        cm = new ControllerMouse(fm, cl);
                        cm.setMp3(mp3);
                        cm.setU(usuaris.get(i));
                        cm.setLlistes(lssss);
                        cm.setCancons(cs);
                        cw = new ControllerWindow();
                        cw.setMp3(mp3);
                        fm.registerController(cUn);
                        fm.registerMouse(cm);
                        fm.registerWindow(cw);
                        fm.setVisible(true);
                        ((JFrame) f).dispose();
                        trobat = true;

                    }

                }

                if(trobat == false){

                    ((FinestraLogin) f).contrasenyaError();

                }
                break;

            case FinestraRegistre.REGISTER:
                Usuari user = new Usuari();
                FinestraRegistre aux = (FinestraRegistre) f;
                String registre = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
                if(user.RegistraUsuari(((FinestraRegistre) f).getNomUsuari(), ((FinestraRegistre) f).getContrasenya(), ((FinestraRegistre) f).getEmail(), registre, registre)){

                    if(((FinestraRegistre) f).getContrasenya().equals(((FinestraRegistre) f).getRepetir())) {


                        LinkedList<Usuari> users = (LinkedList<Usuari>) cl.sendMessage("RU");

                        boolean diferent = true;

                        for (int i = 0; i < users.size(); i++) {

                            if (users.get(i).getNom_usuari().equals(((FinestraRegistre) f).getNomUsuari())) {

                                diferent = false;

                            }

                        }

                        if (diferent) {

                            LinkedList<Canco> cancons = (LinkedList<Canco>) cl.sendMessage("RC");
                            LinkedList<LlistaReproduccio> llistes = (LinkedList<LlistaReproduccio>) cl.sendMessage("RL") ;
                            FinestraMusicaDisponible fm = new FinestraMusicaDisponible(640, 420, cancons, llistes);
                            mp3 = new MP3Reproducer("");
                            cUn = new ControllerAction(fm, cl);
                            cUn.setMp3(mp3);
                            cUn.setU(user);
                            cUn.setCancons(cancons);
                            cUn.setLlistes(llistes);
                            cm = new ControllerMouse(fm, cl);
                            cm.setMp3(mp3);
                            cm.setU(user);
                            cm.setCancons(cancons);
                            cm.setLlistes(llistes);
                            cw = new ControllerWindow();
                            cw.setMp3(mp3);
                            fm.registerController(cUn);
                            fm.registerMouse(cm);
                            fm.registerWindow(cw);
                            fm.setVisible(true);
                            cl.sendWriteMessage("WU");
                            cl.sendObject(user);
                            ((JFrame) f).dispose();

                        } else {

                            ((FinestraRegistre) f).contrasenyaError("Error! Ja hi ha un usuari amb aquest nom!");

                        }
                    }else{

                        ((FinestraRegistre) f).contrasenyaError("Error! T'has equivocat al repetir la contrasenya!");

                    }

                }else{

                    ((FinestraRegistre) f).contrasenyaError("Error! La contrasenya ha de tenir 6 o mes caracters, algun numero i tant majuscules com minuscules.");

                }
                break;

            case FinestraRegistre.BACK:
                FinestraInici fi = new FinestraInici(640,420);
                cIn = new ControllerAction(fi, cl);
                fi.registerController(cIn);
                fi.setVisible(true);
                ((JFrame) f).dispose();
                break;

            case FinestraMusicaDisponible.LLISTES:

                LinkedList<LlistaReproduccio> llistes = (LinkedList<LlistaReproduccio>)cl.sendMessage("RLU-"+u.getNom_usuari());

                FinestraLlistesReproduccio fll = new FinestraLlistesReproduccio(640,420, llistes, u);
                cIn = new ControllerAction(fll, cl);
                cIn.setU(u);
                cIn.setLlistes(llistes);
                cm = new ControllerMouse(fll, cl);
                cm.setU(u);
                cm.setLlistes(llistes);
                fll.registerController(cIn);
                fll.registerMouse(cm);
                fll.setVisible(true);
                ((JFrame) f).dispose();
                break;

            case FinestraLlistesReproduccio.MENU:

                LinkedList<Canco> cancons = (LinkedList<Canco>) cl.sendMessage("RC");
                LinkedList<LlistaReproduccio> lss = (LinkedList<LlistaReproduccio>) cl.sendMessage("RLU-"+u.getNom_usuari());
                FinestraMusicaDisponible fm = new FinestraMusicaDisponible(640, 420, cancons, lss);
                mp3 = new MP3Reproducer("");
                cUn = new ControllerAction(fm, cl);
                cUn.setMp3(mp3);
                cUn.setU(u);
                cUn.setLlistes(lss);
                cUn.setCancons(cancons);
                cm = new ControllerMouse(fm, cl);
                cm.setMp3(mp3);
                cm.setU(u);
                cm.setLlistes(lss);
                cm.setCancons(cancons);
                cw = new ControllerWindow();
                cw.setMp3(mp3);
                fm.registerController(cUn);
                fm.registerMouse(cm);
                fm.registerWindow(cw);
                fm.setVisible(true);
                ((JFrame) f).dispose();
                break;

            case FinestraMusicaDisponible.REFRESH:

                LinkedList<Canco> cs = (LinkedList<Canco>) cl.sendMessage("RC");
                LinkedList<LlistaReproduccio> lis = (LinkedList<LlistaReproduccio>) cl.sendMessage("RL");
                FinestraMusicaDisponible fim = new FinestraMusicaDisponible(640, 420, cs, lis);
                mp3 = new MP3Reproducer("");
                cUn = new ControllerAction(fim, cl);
                cUn.setMp3(mp3);
                cUn.setU(u);
                cUn.setCancons(cs);
                cUn.setLlistes(lis);
                cm = new ControllerMouse(fim, cl);
                cm.setMp3(mp3);
                cm.setU(u);
                cm.setCancons(cs);
                cm.setLlistes(lis);
                cw = new ControllerWindow();
                cw.setMp3(mp3);
                fim.registerController(cUn);
                fim.registerMouse(cm);
                fim.registerWindow(cw);
                fim.setVisible(true);
                ((JFrame) f).dispose();
                break;

            case FinestraLlistesReproduccio.ADDLIST:

                FinestraAfegirLlista fal = new FinestraAfegirLlista(640, 420);
                cUn = new ControllerAction(fal, cl);
                cUn.setU(this.u);
                fal.registerController(cUn);
                fal.setVisible(true);
                ((JFrame) f).dispose();
                break;

            case FinestraAfegirLlista.AFEGIR:
                FinestraAfegirLlista auxiliar = (FinestraAfegirLlista) f;

                LinkedList<LlistaReproduccio> ls = (LinkedList<LlistaReproduccio>) cl.sendMessage("RL");

                if(!auxiliar.getNom().equals("")){

                    int size = (ls == null) ? 0 : ls.size();

                    System.out.println(size + 1);

                    System.out.println(auxiliar.getNom());

                    System.out.println(u.getNom_usuari());

                    LlistaReproduccio l;

                    if(size > 0) {

                        l = new LlistaReproduccio(ls.getLast().getId_llistaReproduccio() + 1, auxiliar.getNom(), u.getNom_usuari());

                    }else{

                        l = new LlistaReproduccio(1, auxiliar.getNom(), u.getNom_usuari());

                    }
                    cl.sendWriteMessage("WL");
                    cl.sendObject(l);
                    System.out.println("ehhh");
                    LinkedList<Canco> css = (LinkedList<Canco>) cl.sendMessage("RC");
                    LinkedList<LlistaReproduccio> lsss = (LinkedList<LlistaReproduccio>) cl.sendMessage("RLU-"+u.getNom_usuari());
                    FinestraLlistesReproduccio fic = new FinestraLlistesReproduccio(640,420, lsss, u);
                    cIn = new ControllerAction(fic, cl);
                    cIn.setLlistes(lsss);
                    cIn.setU(u);
                    cm = new ControllerMouse(fic, cl);
                    cm.setLlistes(lsss);
                    cm.setU(u);
                    fic.registerController(cIn);
                    fic.registerMouse(cm);
                    fic.setVisible(true);
                    ((JFrame) f).dispose();

                }else{

                    ((FinestraAfegirLlista) f).afegirError("Error! Falta el nom!");

                }

                break;

            case FinestraAfegirLlista.MENULLISTES:

                FinestraAfegirLlista a = (FinestraAfegirLlista) f;
                LinkedList<Canco> css = (LinkedList<Canco>) cl.sendMessage("RC");
                LinkedList<LlistaReproduccio> lsss = (LinkedList<LlistaReproduccio>) cl.sendMessage("RLU-"+u.getNom_usuari());
                FinestraMusicaDisponible fic = new FinestraMusicaDisponible(640,420, css, lsss);
                mp3 = new MP3Reproducer("");
                cUn = new ControllerAction(fic, cl);
                cUn.setMp3(mp3);
                cUn.setU(u);
                cUn.setLlistes(lsss);
                cm = new ControllerMouse(fic, cl);
                cm.setMp3(mp3);
                cm.setU(u);
                cm.setLlistes(lsss);
                cw = new ControllerWindow();
                cw.setMp3(mp3);
                fic.registerController(cUn);
                fic.registerMouse(cm);
                fic.registerWindow(cw);
                fic.setVisible(true);
                ((JFrame) f).dispose();

                break;

            case FinestraMusicaLlista.TORNAR:

                LinkedList<LlistaReproduccio> lls = (LinkedList<LlistaReproduccio>)cl.sendMessage("RLU-"+u.getNom_usuari());

                FinestraLlistesReproduccio flll = new FinestraLlistesReproduccio(640,420, lls, u);
                cIn = new ControllerAction(flll, cl);
                cIn.setU(u);
                cIn.setLlistes(lls);
                cm = new ControllerMouse(flll, cl);
                cm.setU(u);
                cm.setLlistes(lls);
                flll.registerController(cIn);
                flll.registerMouse(cm);
                flll.setVisible(true);
                ((JFrame) f).dispose();
                break;

            case FinestraCancoAfegirALlista.TORNAR:

                LinkedList<Canco> cssss = (LinkedList<Canco>) cl.sendMessage("RC");
                LinkedList<LlistaReproduccio> lssss = (LinkedList<LlistaReproduccio>) cl.sendMessage("RLU-"+u.getNom_usuari());
                FinestraMusicaDisponible fmm = new FinestraMusicaDisponible(640, 420, cssss, lssss);
                mp3 = new MP3Reproducer("");
                cUn = new ControllerAction(fmm, cl);
                cUn.setMp3(mp3);
                cUn.setU(u);
                cUn.setLlistes(lssss);
                cUn.setCancons(cssss);
                cm = new ControllerMouse(fmm, cl);
                cm.setMp3(mp3);
                cm.setU(u);
                cm.setLlistes(lssss);
                cm.setCancons(cssss);
                cw = new ControllerWindow();
                cw.setMp3(mp3);
                fmm.registerController(cUn);
                fmm.registerMouse(cm);
                fmm.registerWindow(cw);
                fmm.setVisible(true);
                ((JFrame) f).dispose();
                break;


            case FinestraMusicaDisponible.STRING1:
                if(f.getClass().getSimpleName().equals("FinestraMusicaDisponible")) {

                    FinestraMusicaDisponible auxx = (FinestraMusicaDisponible)f;
                    Vot v = new Vot(u.getNom_usuari(), this.cancons.get(auxx.getRowindex()).getPath_canco(), 1);
                    afegirVot(v);

                }
                if(f.getClass().getSimpleName().equals("FinestraMusicaLlista")){

                    FinestraMusicaLlista auxx = (FinestraMusicaLlista)f;
                    Vot v = new Vot(this.u.getNom_usuari(), this.cancons.get(auxx.getRowindex()).getPath_canco(), 1);
                    afegirVot(v);

                }
                break;

            case FinestraMusicaDisponible.STRING2:
                if(f.getClass().getSimpleName().equals("FinestraMusicaDisponible")) {

                    FinestraMusicaDisponible auxx = (FinestraMusicaDisponible)f;
                    Vot v = new Vot(u.getNom_usuari(), this.cancons.get(auxx.getRowindex()).getPath_canco(), 2);
                    afegirVot(v);

                }

                if(f.getClass().getSimpleName().equals("FinestraMusicaLlista")){

                    FinestraMusicaLlista auxx = (FinestraMusicaLlista)f;
                    Vot v = new Vot(this.u.getNom_usuari(), this.cancons.get(auxx.getRowindex()).getPath_canco(), 2);
                    afegirVot(v);

                }
                break;

            case FinestraMusicaDisponible.STRING3:
                if(f.getClass().getSimpleName().equals("FinestraMusicaDisponible")) {

                    FinestraMusicaDisponible auxx = (FinestraMusicaDisponible)f;
                    Vot v = new Vot(u.getNom_usuari(), this.cancons.get(auxx.getRowindex()).getPath_canco(), 3);
                    afegirVot(v);

                }

                if(f.getClass().getSimpleName().equals("FinestraMusicaLlista")){

                    FinestraMusicaLlista auxx = (FinestraMusicaLlista)f;
                    Vot v = new Vot(this.u.getNom_usuari(), this.cancons.get(auxx.getRowindex()).getPath_canco(), 3);
                    afegirVot(v);

                }
                break;
            case FinestraMusicaDisponible.STRING4:
                if(f.getClass().getSimpleName().equals("FinestraMusicaDisponible")) {

                    FinestraMusicaDisponible auxx = (FinestraMusicaDisponible)f;
                    Vot v = new Vot(u.getNom_usuari(), this.cancons.get(auxx.getRowindex()).getPath_canco(), 4);
                    afegirVot(v);

                }

                if(f.getClass().getSimpleName().equals("FinestraMusicaLlista")){

                    FinestraMusicaLlista auxx = (FinestraMusicaLlista)f;
                    Vot v = new Vot(this.u.getNom_usuari(), this.cancons.get(auxx.getRowindex()).getPath_canco(), 4);
                    afegirVot(v);

                }
                break;

            case FinestraMusicaDisponible.STRING5:
                if(f.getClass().getSimpleName().equals("FinestraMusicaDisponible")) {

                    FinestraMusicaDisponible auxx = (FinestraMusicaDisponible)f;
                    Vot v = new Vot(u.getNom_usuari(), this.cancons.get(auxx.getRowindex()).getPath_canco(), 5);
                    afegirVot(v);

                }

                if(f.getClass().getSimpleName().equals("FinestraMusicaLlista")){

                    FinestraMusicaLlista auxx = (FinestraMusicaLlista)f;
                    Vot v = new Vot(this.u.getNom_usuari(), this.cancons.get(auxx.getRowindex()).getPath_canco(), 5);
                    afegirVot(v);

                }
                break;

            case FinestraMusicaLlista.ELIMINARCANCO:
                FinestraMusicaLlista auxf = (FinestraMusicaLlista)f;
                eliminarCanco(this.cancons.get(auxf.getRowindex()).getPath_canco(), this.id_llista);
                break;

            case FinestraMusicaDisponible.AFEGIRALLISTA:
                FinestraMusicaDisponible auxff = (FinestraMusicaDisponible)f;
                afegirALlista(this.cancons.get(auxff.getRowindex()));
                break;

            case FinestraLlistesReproduccio.ELIMINALLISTA:
                FinestraLlistesReproduccio auxfff = (FinestraLlistesReproduccio)f;
                eliminarLlista(this.llistes.get(auxfff.getRowindex()).getId_llistaReproduccio());
                break;


            case FinestraMusicaDisponible.BUCLE:

                if(f.getClass().getSimpleName().equals("FinestraMusicaDisponible")) {
                    System.out.println("Hola!");

                    FinestraMusicaDisponible auxx = (FinestraMusicaDisponible)f;

                    if(this.mp3.getBucle() == 0){

                        this.mp3.getPlayMP3().setRepeat(true);
                        this.mp3.setBucle(1);

                        ((FinestraMusicaDisponible) f).getJbBucle().setText(FinestraMusicaDisponible.NOBUCLE);

                    }else{

                        this.mp3.getPlayMP3().setRepeat(false);
                        this.mp3.setBucle(0);
                        ((FinestraMusicaDisponible) f).getJbBucle().setText(FinestraMusicaDisponible.BUCLE);

                    }

                }
                if(f.getClass().getSimpleName().equals("FinestraMusicaLlista")){

                    FinestraMusicaLlista auxx = (FinestraMusicaLlista) f;

                    if(this.mp3.getBucle() == 0){

                        this.mp3.getPlayMP3().setRepeat(true);
                        this.mp3.setBucle(1);
                        ((FinestraMusicaLlista) f).getJbBucle().setText(FinestraMusicaLlista.BUCLELLISTA);


                    }else{

                        if(this.mp3.getBucle() == 1){

                            this.mp3.setBucle(2);

                            for(int i = 0; i < this.cancons.size(); i++){

                                try {

                                    Canco c = this.cancons.get(i);

                                    String folder = "cancons/"+ c.getNom()+".mp3";

                                    File f1 = new File(c.getPath_canco());

                                    Path src = Paths.get(f1.getAbsolutePath());
                                    Path dest = Paths.get(folder);


                                    if(!folder.equals(this.mp3.getPath_canco())) {

                                        cl.sendMessage("IV-"+c.getPath_canco());

                                        Files.copy(src, dest, StandardCopyOption.REPLACE_EXISTING);

                                        this.mp3.getPlayMP3().addToPlayList(new File(folder));

                                    }



                                } catch(Exception e1){

                                    e1.printStackTrace();

                                }

                            }
                            ((FinestraMusicaLlista) f).getJbBucle().setText(FinestraMusicaLlista.NOBUCLE);


                        }else {

                            this.mp3.getPlayMP3().setRepeat(false);
                            this.mp3.getPlayMP3().stop();
                            this.mp3.getPlayMP3().getPlayList();
                            this.mp3.setPath_canco(this.mp3.getPath_canco());
                            this.mp3.setBucle(0);
                            ((FinestraMusicaLlista) f).getJbBucle().setText(FinestraMusicaLlista.BUCLE);

                        }

                    }

                }



        }
    }

    /**
     * Elimina una llista de l'usuari.
     * @param id_llista Id de la llista que volem eliminar.
     */

    public void eliminarLlista(int id_llista){

        cl.sendMessage("EL-"+id_llista);

        ControllerAction cIn;
        LinkedList<LlistaReproduccio> llistes = (LinkedList<LlistaReproduccio>) cl.sendMessage("RLU-"+u.getNom_usuari());
        FinestraLlistesReproduccio fc = new FinestraLlistesReproduccio(640,420, llistes, u);
        cIn = new ControllerAction(fc, cl);
        cIn.setLlistes(llistes);
        cIn.setU(u);
        ControllerMouse cm = new ControllerMouse(fc, cl);
        cm.setLlistes(llistes);
        cm.setU(u);
        fc.registerController(cIn);
        fc.registerMouse(cm);
        fc.setVisible(true);
        ((JFrame) f).dispose();

    }

    /**
     * Elimina una canco d'una llista.
     * @param path_canco Path de la canco que volem eliminar de la llista.
     * @param id_llista Id de la llista de la qual volem eliminar una canco.
     */

    public void eliminarCanco(String path_canco, int id_llista){

        cl.sendWriteMessage("ECL");
        cl.sendObject(path_canco);
        cl.sendObject(id_llista);
        LinkedList<Canco> cs = (LinkedList<Canco>) cl.sendMessage("RCL-"+id_llista);
        ControllerAction cIn;
        ControllerMouse cm;
        ControllerWindow cw;
        MP3Reproducer mp3aux;
        mp3aux = new MP3Reproducer("");
        mp3aux.start();
        FinestraMusicaLlista fc = new FinestraMusicaLlista(640,420, cs);
        cIn = new ControllerAction(fc, cl);
        cIn.setMp3(mp3aux);
        cIn.setU(u);
        cIn.setCancons(cs);
        cIn.setId_llista(id_llista);
        cm = new ControllerMouse(fc, cl);
        cm.setMp3(mp3aux);
        cm.setU(u);
        cm.setCancons(cs);
        cw = new ControllerWindow();
        cw.setMp3(mp3aux);
        fc.registerController(cIn);
        fc.registerMouse(cm);
        fc.registerWindow(cw);
        fc.setVisible(true);
        ((JFrame) f).dispose();

    }

    /**
     * Afegeix una canco a una llista de l'usuari.
     * @param c Canco que es vol afegir.
     */


    public void afegirALlista(Canco c){

        LinkedList<LlistaReproduccio> llistes = (LinkedList<LlistaReproduccio>)cl.sendMessage("RLU-"+u.getNom_usuari());
        FinestraCancoAfegirALlista fmm = new FinestraCancoAfegirALlista(640, 420, llistes);
        ControllerAction cUn = new ControllerAction(fmm, cl);
        cUn.setU(u);
        cUn.setLlistes(llistes);
        ControllerMouse cm = new ControllerMouse(fmm, cl);
        cm.setC(c);
        cm.setU(u);
        cm.setLlistes(llistes);
        fmm.registerController(cUn);
        fmm.registerMouse(cm);
        fmm.setVisible(true);
        ((JFrame) f).dispose();

    }

    /**
     * Puja un vot a la base de dades.
     * @param v Vot que es vol pujar a la base.
     */

    public void afegirVot(Vot v){

        cl.sendWriteMessage("UV");
        cl.sendObject(v);

    }

    public void setMp3(MP3Reproducer mp3) {
        this.mp3 = mp3;
    }

    public MP3Reproducer getMp3() {
        return mp3;
    }

    public Usuari getU() {
        return u;
    }

    public void setU(Usuari u) {
        this.u = u;
    }

    public LinkedList<LlistaReproduccio> getLlistes() {
        return llistes;
    }

    public void setLlistes(LinkedList<LlistaReproduccio> llistes) {
        this.llistes = llistes;
    }

    public LinkedList<Canco> getCancons() {
        return cancons;
    }

    public void setCancons(LinkedList<Canco> cancons) {
        this.cancons = cancons;
    }

    public int getId_llista() {
        return id_llista;
    }

    public void setId_llista(int id_llista) {
        this.id_llista = id_llista;
    }
}
