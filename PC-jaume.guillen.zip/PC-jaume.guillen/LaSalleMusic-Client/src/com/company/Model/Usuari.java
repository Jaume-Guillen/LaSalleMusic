package com.company.Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Usuari registrat a la base de dades.
 */

public class Usuari implements Serializable {

    String nom_usuari;
    String email;
    String contrasenya;
    String data_registre;
    String darrer_acces;
    LinkedList<LlistaReproduccio> llistes = new LinkedList<LlistaReproduccio>();
    LinkedList<String> nom_amics;
    static final long serialVersionUID = 1L;

    /**
     * Constructor de l'usuari. Inicialitzem les variables al registrar-lo.
     */

    public Usuari(){

        this.nom_usuari = "";
        this.email = "";
        this.contrasenya = "";
        this.data_registre = "";
        this.darrer_acces = "";

    }

    /**
     * Inicialitza les variables de l'usuari i comprova si les dades son correctes.
     * @param nom_usuari Nom de l'usuari.
     * @param oontrasenya Contrassenya de l'usuari.
     * @param email Email de l'usuari.
     * @param data_registre Data en que l'usuari es va registrar.
     * @param darrer_acces Data en que l'usuari va accedir per ultim cop.
     * @return Retorna un boolea segons si les dades son correctes o no.
     */

    public boolean RegistraUsuari(String nom_usuari, String oontrasenya, String email, String data_registre, String darrer_acces){

        if(oontrasenya.length() >= 6 && CheckUpper(oontrasenya) && CheckLower(oontrasenya) && CheckDigit(oontrasenya) && !nom_usuari.equals("") && !email.equals("")){

            this.nom_usuari = nom_usuari;
            this.email = email;
            this.contrasenya = oontrasenya;
            this.data_registre = data_registre;
            this.darrer_acces = darrer_acces;
            return true;

        }else{

            System.out.println("Error! La contrasenya ha de tenir 6 o mes caracters, algun numero i tant majuscules com minuscules.");

            return false;

        }

    }

    /**
     * Comprova si hi ha un caracter en majuscula en un String.
     * @param check String a comprovar.
     * @return Boolea conforme hi ha una majuscula o no.
     */

    private boolean CheckUpper(String check){

        for(int i = 0; i < check.length(); i++){

            if(Character.isUpperCase(check.charAt(i))){

                return true;

            }

        }

        return false;

    }

    /**
     * Comprova si hi ha un caracter en minuscula en un String.
     * @param check String a comprovar.
     * @return Boolea conforme hi ha una minuscula o no.
     */

    private boolean CheckLower(String check){

        for(int i = 0; i < check.length(); i++){

            if(Character.isLowerCase(check.charAt(i))){

                return true;

            }

        }

        return false;

    }

    /**
     * Comprova si hi ha un digit en un String.
     * @param check String a comprovar.
     * @return Boolea conforme hi ha un digit o no.
     */

    private boolean CheckDigit(String check){

        for(int i = 0; i < check.length(); i++){

            if(Character.isDigit(check.charAt(i))){

                return true;

            }

        }

        return false;

    }

    public String getNom_usuari() {
        return nom_usuari;
    }

    public void setNom_usuari(String nom_usuari) {
        this.nom_usuari = nom_usuari;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContrasenya() {
        return contrasenya;
    }

    public void setContrasenya(String contrasenya) {
        this.contrasenya = contrasenya;
    }

    public LinkedList<LlistaReproduccio> getLlistes() {
        return llistes;
    }

    public void setLlistes(LinkedList<LlistaReproduccio> llistes) {
        this.llistes = llistes;
    }

    public LinkedList<String> getNom_amics() {
        return nom_amics;
    }

    public void setNom_amics(LinkedList<String> nom_amics) {
        this.nom_amics = nom_amics;
    }

    public String getData_registre() {
        return data_registre;
    }

    public void setData_registre(String data_registre) {
        this.data_registre = data_registre;
    }

    public String getDarrer_acces() {
        return darrer_acces;
    }

    public void setDarrer_acces(String darrer_acces) {
        this.darrer_acces = darrer_acces;
    }
}
