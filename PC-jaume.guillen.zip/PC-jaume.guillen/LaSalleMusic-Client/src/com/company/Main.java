package com.company;

import com.company.Controlador.ControllerAction;
import com.company.Model.Config;
import com.company.Network.Client;
import com.company.Vista.FinestraInici;

public class Main {

    public static void main(String[] args) {
        try {

            Config conf;

            conf = Config.getInstance();

            Client cl = new Client(conf.getIp(), conf.getPort());
            cl.start();

            FinestraInici fi = new FinestraInici(640, 480);

            ControllerAction c = new ControllerAction(fi, cl);

            fi.registerController(c);

            fi.setVisible(true);



        }catch(Exception e){

            e.printStackTrace();

        }


    }
}
