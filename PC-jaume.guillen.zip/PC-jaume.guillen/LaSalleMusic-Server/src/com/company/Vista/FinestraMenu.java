package com.company.Vista;

import com.company.Controlador.ControllerAction;
import com.company.Controlador.ControllerMouse;
import com.company.Model.Usuari;

import javax.swing.*;
import java.awt.*;

/**
 * Menu que apareix un cop s'ha accedit al sistema.
 */

public class FinestraMenu extends JFrame implements Finestra{
    public final static String CANCONS = "CANCONS";
    public final static String USUARIS = "USUARIS";
    JButton botoCancons;
    JButton botoUsuaris;

    /**
     * Inicialitza la finestra i la mostra per pantalla.
     * @param w Amplada de la finestra.
     * @param h Llargada de la finestra.
     */

    public FinestraMenu(int w, int h){

        setSize(new Dimension(w, h));
        setTitle("LaSalle Music");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        JPanel titol = new JPanel();
        titol.setMaximumSize(new Dimension(w, h/2));
        JPanel botons = new JPanel();
        botons.setMaximumSize(new Dimension(w, h/2));
        botoCancons = new JButton(CANCONS);
        botoUsuaris = new JButton(USUARIS);
        setLayout(new GridLayout(2,1));
        add(titol);
        botons.add(botoCancons);
        botons.add(botoUsuaris);
        add(botons);

    }

    public void registerController(ControllerAction c) {

        this.botoCancons.setActionCommand(CANCONS);
        this.botoCancons.addActionListener(c);
        this.botoUsuaris.setActionCommand(USUARIS);
        this.botoUsuaris.addActionListener(c);

    }

    @Override
    public void registerMouse(ControllerMouse c) {

    }
}
