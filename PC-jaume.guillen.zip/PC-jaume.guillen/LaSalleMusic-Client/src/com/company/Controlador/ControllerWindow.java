package com.company.Controlador;

import com.company.Model.MP3Reproducer;
import com.company.Vista.Finestra;
import com.company.Vista.FinestraMusicaDisponible;
import com.company.Vista.FinestraMusicaLlista;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;

/**
 * Controlador que para el reproductor de musica si s'ha canviat de finestra.
 */

public class ControllerWindow implements WindowListener {

    MP3Reproducer mp3;
    public ControllerWindow(){

    }
    @Override
    public void windowOpened(WindowEvent e) {

    }

    @Override
    public void windowClosing(WindowEvent e) {

    }

    @Override
    public void windowClosed(WindowEvent e) {

        if(!mp3.getPath_canco().equals("")) {

            mp3.getPlayMP3().stop();
            mp3.setPlaying(false);

        }

        File directory = new File("cancons/");

        File[] files = directory.listFiles();

        for(File file: files){

            if(file.delete()){

                System.out.println("Fitxer eliminat!");

            }

        }

    }

    @Override
    public void windowIconified(WindowEvent e) {

    }

    @Override
    public void windowDeiconified(WindowEvent e) {

    }

    @Override
    public void windowActivated(WindowEvent e) {

    }

    @Override
    public void windowDeactivated(WindowEvent e) {

    }

    public void setMp3(MP3Reproducer mp3) {
        this.mp3 = mp3;
    }
}
