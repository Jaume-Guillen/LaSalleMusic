package com.company.Network;
import com.company.Network.DedicatedServer;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;

/**
 * Servidor general de la aplicacio.
 */

public class Server extends Thread{

    ServerSocket listener;
    LinkedList<DedicatedServer> ds = new LinkedList<>();

    /**
     * Constructor del servidor.
     * @param port Port de comunicacio del servidor amb el client.
     * @throws IOException
     */
    public Server(int port) throws IOException {
        try {
            listener = new ServerSocket(port);
        }catch(Exception e){

            e.printStackTrace();

        }

    }

    /**
     * El servidor corre en paralel per detectar clients.
     */


    public void run(){

        System.out.println("Server running...");
        while (true) {

            try {

                Socket s = listener.accept();

                ds.add(new DedicatedServer(listener, s, this));
                ds.getLast().start();
            }catch(Exception e){

                e.printStackTrace();

            }

        }

    }

    public LinkedList<DedicatedServer> getDs() {
        return ds;
    }
}
