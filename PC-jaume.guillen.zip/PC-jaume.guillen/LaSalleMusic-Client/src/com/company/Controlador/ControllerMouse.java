package com.company.Controlador;

import com.company.Model.Canco;
import com.company.Model.LlistaReproduccio;
import com.company.Model.MP3Reproducer;
import com.company.Model.Usuari;
import com.company.Network.Client;
import com.company.Vista.*;

import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.LinkedList;

/**
 * Controlador del mouse. S'utilitza per gestionar les accions que passen quan l'usuari interracciona amb una taula.
 */

public class ControllerMouse implements MouseListener {
    Finestra f;
    Client cl;
    MP3Reproducer mp3;
    Canco c;
    Usuari u;
    LinkedList<LlistaReproduccio> llistes;
    LinkedList<Canco> cancons;

    /**
     * Constructor del controlaoor del mouse.
     * @param f Finestra activa en aquell moment.
     * @param cl Client del programa.
     */

    public ControllerMouse(Finestra f, Client cl){

        this.f = f;
        this.cl = cl;

    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

        if(f.getClass().getSimpleName().equals("FinestraMusicaLlista")) {

            FinestraMusicaLlista aux = (FinestraMusicaLlista)f;

            int r = aux.getTaula().rowAtPoint(e.getPoint());
            if (r >= 0 && r < aux.getTaula().getRowCount()) {
                aux.getTaula().setRowSelectionInterval(r, r);
            } else {
                aux.getTaula().clearSelection();
            }

            aux.setRowindex(aux.getTaula().getSelectedRow());

            if (SwingUtilities.isRightMouseButton(e)) {
                if (aux.getRowindex() < 0)
                    return;
                aux.getPopup().show(e.getComponent(), e.getX(), e.getY());
            }

            if (SwingUtilities.isLeftMouseButton(e)) {

                Canco row = cancons.get(aux.getRowindex());
                reprodueixCanco(row);
                aux.getGroup().clearSelection();
                if (mp3.getPlayMP3() != null) {
                    mp3.getPlayMP3().setRepeat(false);
                }
                aux.getJbBucle().setText(FinestraMusicaDisponible.BUCLE);
                aux.getButton1().setVisible(true);
                aux.getButton2().setVisible(true);
                aux.getButton3().setVisible(true);
                aux.getButton4().setVisible(true);
                aux.getButton5().setVisible(true);
                aux.getJbBucle().setVisible(true);

            }

        }

        if(f.getClass().getSimpleName().equals("FinestraMusicaDisponible")){

            FinestraMusicaDisponible aux = (FinestraMusicaDisponible)f;
            int r = aux.getTaula().rowAtPoint(e.getPoint());
            if (r >= 0 && r < aux.getTaula().getRowCount()) {
                aux.getTaula().setRowSelectionInterval(r, r);
            } else {
                aux.getTaula().clearSelection();
            }

            aux.setRowindex(aux.getTaula().getSelectedRow());

            if(SwingUtilities.isRightMouseButton(e)) {
                if (aux.getRowindex() < 0)
                    return;
                    aux.getPopup().show(e.getComponent(), e.getX(), e.getY());
            }

            if(SwingUtilities.isLeftMouseButton(e)) {

                Canco row = cancons.get(aux.getRowindex());
                reprodueixCanco(row);
                aux.getGroup().clearSelection();
                if(mp3.getPlayMP3()!= null) {
                    mp3.getPlayMP3().setRepeat(false);
                }
                aux.getJbBucle().setText(FinestraMusicaDisponible.BUCLE);
                aux.getButton1().setVisible(true);
                aux.getButton2().setVisible(true);
                aux.getButton3().setVisible(true);
                aux.getButton4().setVisible(true);
                aux.getButton5().setVisible(true);
                aux.getJbBucle().setVisible(true);

            }

        }

        if(f.getClass().getSimpleName().equals("FinestraCancoAfegirALlista")){

            FinestraCancoAfegirALlista aux = (FinestraCancoAfegirALlista)f;
            int r = aux.getTaula().rowAtPoint(e.getPoint());
            if (r >= 0 && r < aux.getTaula().getRowCount()) {
                aux.getTaula().setRowSelectionInterval(r, r);
            } else {
                aux.getTaula().clearSelection();
            }

            aux.setRowindex(aux.getTaula().getSelectedRow());
            if(SwingUtilities.isLeftMouseButton(e)) {

                int row = llistes.get(aux.getRowindex()).getId_llistaReproduccio();
                String path_canco = c.getPath_canco();
                afegeixCanco(row, path_canco);

            }

        }

        if(f.getClass().getSimpleName().equals("FinestraLlistesReproduccio")){

            FinestraLlistesReproduccio aux = (FinestraLlistesReproduccio)f;
            int r = aux.getTaula().rowAtPoint(e.getPoint());
            if (r >= 0 && r < aux.getTaula().getRowCount()) {
                aux.getTaula().setRowSelectionInterval(r, r);
            } else {
                aux.getTaula().clearSelection();
            }

            aux.setRowindex(aux.getTaula().getSelectedRow());

            if(SwingUtilities.isRightMouseButton(e)) {
                if (aux.getRowindex() < 0)
                    return;
                    aux.getPopup().show(e.getComponent(), e.getX(), e.getY());
            }

            if(SwingUtilities.isLeftMouseButton(e)) {

                int row = llistes.get(aux.getRowindex()).getId_llistaReproduccio();
                this.accedeixLlista(row);

            }

        }

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    public void setMp3(MP3Reproducer mp3) {
        this.mp3 = mp3;
    }

    public MP3Reproducer getMp3() {
        return mp3;
    }

    /**
     * Reprodueix una canco d'una de les taules del programa.
     * @param c Canco a reproduir.
     */

    public void reprodueixCanco(Canco c){

        String folder = "cancons/"+ c.getNom()+".mp3";

        try {

            File f1 = new File(c.getPath_canco());

            Path src = Paths.get(f1.getAbsolutePath());
            Path dest = Paths.get(folder);


            if(folder.equals(mp3.getPath_canco())){

                if(mp3.getPlayMP3().isPaused()){

                    mp3.getPlayMP3().play();

                }else {

                    mp3.getPlayMP3().pause();

                }
                mp3.setPlaying(false);



            }else {

                cl.sendMessage("IV-"+c.getPath_canco());

                Files.copy(src, dest, StandardCopyOption.REPLACE_EXISTING);

                if(!mp3.getPath_canco().equals("")) {

                    File file = new File(mp3.getPath_canco());


                    if(file.delete()){



                    }


                    mp3.getPlayMP3().stop();
                    mp3.setPlaying(false);

                }

                mp3.setPath_canco(folder);

            }



        } catch(Exception e){

            e.printStackTrace();

        }

    }

    /**
     * Afegeix una canco a la llista d'una taula.
     * @param id_llista L'id de la llista que volem afegir.
     * @param path_canco El path de la canco que volem afegir a la llista.
     */

    public void afegeixCanco(int id_llista, String path_canco){

        cl.sendWriteMessage("WLC");
        cl.sendObject(id_llista);
        cl.sendObject(path_canco);
        LinkedList<Canco> cssss = (LinkedList<Canco>) cl.sendMessage("RC");
        LinkedList<LlistaReproduccio> lssss = (LinkedList<LlistaReproduccio>) cl.sendMessage("RLU-"+u);
        FinestraMusicaDisponible fm = new FinestraMusicaDisponible(640, 420, cssss, lssss);
        MP3Reproducer mp3aux;
        mp3aux = new MP3Reproducer("");
        mp3aux.start();
        ControllerAction c = new ControllerAction(fm, cl);
        c.setMp3(mp3aux);
        c.setCancons(cssss);
        c.setU(u);
        c.setLlistes(lssss);
        ControllerMouse cm = new ControllerMouse(fm, cl);
        cm.setMp3(mp3aux);
        cm.setCancons(cssss);
        cm.setU(u);
        cm.setLlistes(lssss);
        ControllerWindow cw = new ControllerWindow();
        cw.setMp3(mp3aux);
        fm.registerController(c);
        fm.registerMouse(cm);
        fm.registerWindow(cw);
        fm.setVisible(true);
        ((JFrame) f).dispose();


    }

    /**
     * Permet a l'usuari accedir a una de les seves llistes de reproduccio.
     * @param id_llista I de la llista a la que volem accedir.
     */

    public void accedeixLlista(int id_llista){

        LinkedList<LlistaReproduccio> ls = (LinkedList<LlistaReproduccio>) cl.sendMessage("RL");

        for(int i = 0; i < ls.size(); i++){

            if(id_llista == ls.get(i).getId_llistaReproduccio()){

                LinkedList<Canco> cs = (LinkedList<Canco>) cl.sendMessage("RCL-"+id_llista);

                ControllerAction cIn;
                ControllerMouse cm;
                ControllerWindow cw;
                MP3Reproducer mp3aux;
                mp3aux = new MP3Reproducer("");
                mp3aux.start();
                FinestraMusicaLlista fc = new FinestraMusicaLlista(640,420, cs);
                cIn = new ControllerAction(fc, cl);
                cIn.setMp3(mp3aux);
                cIn.setU(u);
                cIn.setCancons(cs);
                cIn.setId_llista(id_llista);
                cm = new ControllerMouse(fc, cl);
                cm.setMp3(mp3aux);
                cm.setU(u);
                cm.setCancons(cs);
                cw = new ControllerWindow();
                cw.setMp3(mp3aux);
                fc.registerController(cIn);
                fc.registerMouse(cm);
                fc.registerWindow(cw);
                fc.setVisible(true);
                ((JFrame) f).dispose();

            }

        }
    }

    public Canco getC() {
        return c;
    }

    public void setC(Canco c) {
        this.c = c;
    }

    public Usuari getU() {
        return u;
    }

    public void setU(Usuari u) {
        this.u = u;
    }

    public LinkedList<LlistaReproduccio> getLlistes() {
        return llistes;
    }

    public void setLlistes(LinkedList<LlistaReproduccio> llistes) {
        this.llistes = llistes;
    }

    public LinkedList<Canco> getCancons() {
        return cancons;
    }

    public void setCancons(LinkedList<Canco> cancons) {
        this.cancons = cancons;
    }
}
