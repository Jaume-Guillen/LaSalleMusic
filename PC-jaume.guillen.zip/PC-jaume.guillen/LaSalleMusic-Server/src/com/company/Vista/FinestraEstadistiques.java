package com.company.Vista;

import com.company.Controlador.ControllerAction;
import com.company.Controlador.ControllerMouse;
import com.company.Model.Canco;
import com.company.Model.Usuari;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.util.LinkedList;

/**
 * Finestra que mostra quines son les 10 millors cancons.
 */

public class FinestraEstadistiques extends JFrame implements Finestra{

    public final static String MENUCANCONS = "TORNAR ENRERA";
    private JButton jbEnrera = new JButton(MENUCANCONS);

    /**
     * Inicialitza la finestra i la mostra.
     * @param w Amplada de la finestra.
     * @param h Llargada de la finestra.
     * @param cancons Top 10 cancons mes vistes.
     */

    public FinestraEstadistiques(int w, int h, LinkedList<Canco> cancons){

        setSize(new Dimension(w, h));
        setTitle("LaSalle Music");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        JPanel p = new JPanel();
        p.setLayout(new GridLayout(5, 2));
        p.setBounds(0, 0, w, h/4);
        p.setMaximumSize(new Dimension(w, h/4));

        if(cancons.size()> 0) {

            int maxViews = cancons.get(0).getReproduccions_totals();

            JRectangles rectangles = new JRectangles();
            add(rectangles, BorderLayout.CENTER);

            for (int i = 0; i < 10; i++) {

                if (i < cancons.size()) {

                    int views = cancons.get(i).getReproduccions_totals();

                    if(maxViews > 0) {

                        rectangles.addRectangle(w / 12 + ((i * w) / (12)), h / 4, w / 13, (views * h) / (2 * maxViews));

                    }

                    JLabel nom = new JLabel((i + 1) + ".- " + cancons.get(i).getNom() + ": " + cancons.get(i).getReproduccions_totals());

                    nom.setBounds(w / 12 + ((i * w) / (12)), h / 4 - h / 16, w / 13, h / 16);

                    p.add(nom);
                } else {

                    JLabel nom = new JLabel("");

                    nom.setBounds(w / 12 + ((i * w) / (12)), h / 4 - h / 16, w / 13, h / 16);

                    p.add(nom);

                }


            }

            rectangles.setLayout(new BorderLayout());
            rectangles.add(p, BorderLayout.NORTH);

        }

        jbEnrera.setBounds(w/2 - w/16, h - h/16, w/8, h/16);

        this.add(jbEnrera, BorderLayout.SOUTH);
    }

    @Override
    public void registerController(ControllerAction c) {

        this.jbEnrera.setActionCommand(MENUCANCONS);
        this.jbEnrera.addActionListener(c);

    }

    @Override
    public void registerMouse(ControllerMouse c) {

    }

}
