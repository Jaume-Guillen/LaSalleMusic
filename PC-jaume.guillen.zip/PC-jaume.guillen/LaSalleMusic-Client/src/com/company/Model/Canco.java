package com.company.Model;

import java.io.Serializable;

/**
 * Canco que es troba dins del programa.
 */

public class Canco implements Serializable {

    String path_canco;
    String nom;
    String genere;
    String album;
    String artista;
    float estrelles;
    int reproduccions_totals;
    static final long serialVersionUID = 42L;

    public String getPath_canco() {
        return path_canco;
    }

    public void setPath_canco(String path_canco) {
        this.path_canco = path_canco;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getGenere() {
        return genere;
    }

    public void setGenere(String genere) {
        this.genere = genere;
    }

    public String getAlbum() {
        return album;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public float getEstrelles() {
        return estrelles;
    }

    public void setEstrelles(float estrelles) {
        this.estrelles = estrelles;
    }

    public int getReproduccions_totals() {
        return reproduccions_totals;
    }

    public void setReproduccions_totals(int reproduccions_totals) {
        this.reproduccions_totals = reproduccions_totals;
    }
}
