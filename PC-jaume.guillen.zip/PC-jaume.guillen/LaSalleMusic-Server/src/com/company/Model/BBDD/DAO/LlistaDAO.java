package com.company.Model.BBDD.DAO;

import com.company.Model.LlistaReproduccio;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

/**
 * Classe que gestiona la taula LlistaReproduccio de la base de dades.
 */

public class LlistaDAO {

    /**
     * Constructor buit de LlistaDAO.
     */

    public LlistaDAO() {



    }

    /**
     * Afegeix una llista a la base de dades.
     * @param l Llista a afegir.
     */

    public void addLlista(LlistaReproduccio l) {

        DBConnector.getInstance().insertQuery("INSERT INTO LlistaReproduccio(id_llista, nom, nom_usuari) VALUES ('"+l.getId_llistaReproduccio()+"', '"+l.getNom()+"', '"+l.getNom_usuari()+"');");

    }

    /**
     * Afegeix una canco a una llista.
     * @param id_llista Llista a la que afegim la canco.
     * @param path_canco Path de la canco a afegir a la llista.
     */

    public void addLlistaCanco(int id_llista, String path_canco) {

        DBConnector.getInstance().insertQuery("INSERT INTO CancoLlista(path_canco, id_llista) VALUES ('"+path_canco+"', "+id_llista+");");

    }

    /**
     * Permet obtenir totes les llistes de la base de dades.
     * @return Retorna totes les llistes de la base de dades.
     */

    public LinkedList<LlistaReproduccio> getAllLlistes() {
        LinkedList<LlistaReproduccio> llistes = new LinkedList<>();
        ResultSet resultat = DBConnector.getInstance().selectQuery("SELECT id_llista, nom, nom_usuari FROM LlistaReproduccio;");
        try{
            while(resultat.next()){
                int id_llistaReproduccio = resultat.getInt("id_llista");
                String nom = resultat.getString("nom");
                String nom_usuari = resultat.getString("nom_usuari");
                llistes.add(new LlistaReproduccio(id_llistaReproduccio, nom, nom_usuari));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return llistes;
    }

    /**
     * Permet obtenir totes les llistes d'un usuari.
     * @param fk FK de l'usuari del que volem les llistes.
     * @return Retorna totes les llistes de l'usuari.
     */

    public LinkedList<LlistaReproduccio> getLlistesUsuari(String fk) {
        LinkedList<LlistaReproduccio> llistes = new LinkedList<>();
        ResultSet resultat = DBConnector.getInstance().selectQuery("SELECT id_llista, nom, nom_usuari FROM LlistaReproduccio WHERE nom_usuari LIKE '" + fk + "';");

        try{
            while(resultat.next()){
                int id_llistaReproduccio = resultat.getInt("id_llista");
                String nom = resultat.getString("nom");
                String nom_usuari = resultat.getString("nom_usuari");
                llistes.add(new LlistaReproduccio(id_llistaReproduccio, nom, nom_usuari));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return llistes;
    }

    /**
     * Permet eliminar una llista de la base de dades.
     * @param id_llista El FK de la llista a eliminar.
     */

    public void deleteLlista(int id_llista) {
        DBConnector.getInstance().deleteQuery("DELETE FROM LlistaReproduccio WHERE id_llista = "+id_llista+";");
    }

    /**
     * Elimina una canco d'una llista.
     * @param path_canco FK de la canco que volem eliminar.
     * @param id_llista FK de la llista de on volem eliminar una canco.
     */

    public void deleteCancoLlista(String path_canco, int id_llista){

        DBConnector.getInstance().deleteQuery("DELETE FROM CancoLlista WHERE id_llista = " + id_llista + " AND path_canco LIKE '" + path_canco +"';");

    }

}
