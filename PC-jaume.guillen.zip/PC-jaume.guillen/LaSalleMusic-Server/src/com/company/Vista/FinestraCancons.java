package com.company.Vista;

import com.company.Controlador.ControllerAction;
import com.company.Controlador.ControllerMouse;
import com.company.Model.Canco;
import com.company.Model.Usuari;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.LinkedList;

/**
 * Mostra totes les cancons de la base de dades.
 */

public class FinestraCancons extends JFrame implements Finestra{

    public final static String MENU = "MENU";
    public final static String ADDSONG = "Afegir Canco";
    public final static String STATS = "Estadistiques";
    public final static String ELIMINARCANCO = "Eliminar canco";
    JTable taula;
    JPopupMenu popup = new JPopupMenu("Eliminar");
    JMenuItem JEliminar = new JMenuItem("Eliminar");
    JMenuItem JCancelar = new JMenuItem("Cancelar");
    JButton JbEnrera = new JButton(MENU);
    JButton JbAfegir = new JButton(ADDSONG);
    JButton JbStats = new JButton(STATS);
    JPanel JpButtons = new JPanel();

    int rowindex = -1;

    /**
     * Constructor de la finestra.
     * @param w Amplada de la finestra.
     * @param h Llargada de la finestra.
     * @param cancons Llistat de cancons al sistema.
     */

    public FinestraCancons(int w, int h, LinkedList<Canco> cancons){

        setSize(new Dimension(w, h));
        setTitle("LaSalle Music");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        String[] columnNames = {"Nom canco", "Genere", "Album", "Artista"};
        Object[][] data = new Object[cancons.size()][4];

        for(int i = 0; i < cancons.size(); i++){

            data[i][0] = cancons.get(i).getNom();
            data[i][1] = cancons.get(i).getGenere();
            data[i][2] = cancons.get(i).getAlbum();
            data[i][3] = cancons.get(i).getArtista();

        }

        taula = new JTable(data, columnNames);

        JbEnrera.setBounds(w/2 - w/16, h - h/8, w/8, h/16);
        JpButtons.setBounds(0, h - h/8, w, h/16);
        JpButtons.add(JbEnrera);
        JbAfegir.setBounds(w/4 - w/16, h - h/8, w/8, h/16);
        JpButtons.add(JbAfegir);
        JbStats.setBounds(3*w/4 - w/16, h - h/8, w/8, h/16);
        popup.add(JEliminar);
        popup.add(JCancelar);
        JpButtons.add(JbStats);
        this.add(new JScrollPane(taula));
        this.add(JpButtons, BorderLayout.SOUTH);

    }

    public void registerMouse(ControllerMouse c){

        taula.addMouseListener(c);

    }

    public void registerController(ControllerAction c){

        this.JEliminar.setActionCommand(ELIMINARCANCO);
        this.JEliminar.addActionListener(c);

        this.JbEnrera.setActionCommand(MENU);
        this.JbEnrera.addActionListener(c);

        this.JbAfegir.setActionCommand(ADDSONG);
        this.JbAfegir.addActionListener(c);

        this.JbStats.setActionCommand(STATS);
        this.JbStats.addActionListener(c);

    }

    public JTable getTaula() {
        return taula;
    }

    public JPopupMenu getPopup() {
        return popup;
    }

    public int getRowindex() {
        return rowindex;
    }

    public void setRowindex(int rowindex) {
        this.rowindex = rowindex;
    }

}
