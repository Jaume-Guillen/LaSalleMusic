package com.company.Vista;

import com.company.Controlador.ControllerAction;
import com.company.Controlador.ControllerMouse;

/**
 * Interficie de totes les finestres del programa.
 */

public interface Finestra{

    /**
     * Enregistra un controlador a la Finestra.
     * @param c Controlador a enregistrar.
     */

    void registerController(ControllerAction c);

    void registerMouse(ControllerMouse c);

}
